import random
import re
from typing import List, Any
from schemas import (
    QuestionBase, SingleChoiceQuestion, MultipleChoiceQuestion, TrueFalseQuestion,
    QuestionType, QuestionEvaluationResult, ShuffleResult, LLMOutput
)
from config import config
from llm_client import llm_client
from prompts import PromptManager

class Evaluator:

    def _get_options_and_correct(self, q: QuestionBase):

        if isinstance(q, SingleChoiceQuestion):
            options = [q.answer] + q.distractors
            correct = [q.answer]
        elif isinstance(q, MultipleChoiceQuestion):
            options = q.correct_options + q.distractors
            correct = q.correct_options
        elif isinstance(q, TrueFalseQuestion):
            options = ["True", "False"]

            if q.answer == "正确":
                correct = ["True"]
            elif q.answer == "错误":
                correct = ["False"]
            else:
                correct = [q.answer]
        else:
            raise ValueError(f"Unknown input type: {type(q)}")
        return options, correct

    def _map_llm_answer_to_content(self, llm_ans: Any, shuffled_options: List[str]) -> List[str]:

        if isinstance(llm_ans, str):
            llm_ans = [llm_ans]

        selected_content = []
        chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

        for ans_item in llm_ans:
            ans_str = str(ans_item).strip()


            for opt in shuffled_options:
                if ans_str == opt:
                    selected_content.append(opt)
                    break
            if selected_content and selected_content[-1] == ans_str:
                 continue

            letters = []
            for m in re.finditer(r"\boption\s*([A-Z])\b", ans_str, flags=re.IGNORECASE):
                letters.append(m.group(1).upper())
            if not letters:
                for m in re.finditer(r"(?<![A-Z0-9])([A-Z])(?:[\.\)\:]|\b)", ans_str.upper()):
                    letters.append(m.group(1))
            letters = [c for c in letters if c in chars]
            if letters:
                for c in letters:
                    idx = chars.index(c)
                    if 0 <= idx < len(shuffled_options):
                        selected_content.append(shuffled_options[idx])
                continue

            target_idx = -1


            if ans_str.lower().startswith("option "):
                candidate = ans_str.split()[1].upper().replace(".", "").replace(",", "").replace(")", "").replace(":", "")
                if len(candidate) == 1 and candidate in chars:
                    target_idx = chars.index(candidate)


            elif len(ans_str) > 0:
                first_char = ans_str[0].upper()
                if first_char in chars:
                    if len(ans_str) == 1:
                        target_idx = chars.index(first_char)
                    elif ans_str[1] == '.':
                        target_idx = chars.index(first_char)
                    elif ans_str[1] == ' ' and first_char in chars:
                         target_idx = chars.index(first_char)

            if target_idx != -1 and target_idx < len(shuffled_options):
                selected_content.append(shuffled_options[target_idx])
            else:

                norm_ans = ans_str.lower()
                for opt in shuffled_options:
                    if norm_ans == opt.lower() or norm_ans in opt.lower():
                        if norm_ans == opt.lower():
                            selected_content.append(opt)
                            break
                        clean_llm = ans_str
                        if len(clean_llm) > 3 and clean_llm[1] == '.' and clean_llm[2] == ' ':
                            clean_llm = clean_llm[3:].strip()
                            if clean_llm.lower() == opt.lower():
                                selected_content.append(opt)
                                break

        return selected_content

    def _calculate_correctness_and_score(self, selected_content: List[str], correct_content: List[str], qtype: QuestionType):

        sel_set = set(selected_content)
        corr_set = set(correct_content)

        if qtype == QuestionType.SINGLE_CHOICE or qtype == QuestionType.TRUE_FALSE:
            is_correct = (sel_set == corr_set)
            return is_correct, 1.0 if is_correct else 0.0

        elif qtype == QuestionType.MULTIPLE_CHOICE:
            if sel_set == corr_set:
                return True, 5.0


            errors = sel_set - corr_set
            if errors:
                return False, 0.0


            if sel_set.issubset(corr_set) and len(sel_set) > 0:
                return False, 3.0

            return False, 0.0

    def evaluate_single_turn(self, q: QuestionBase, llm_response: str, shuffled_options: List[str]):

        original_options, correct_content = self._get_options_and_correct(q)

        selected_content = self._map_llm_answer_to_content(llm_response, shuffled_options)

        is_correct, score = self._calculate_correctness_and_score(selected_content, correct_content, q.qtype)

        return ShuffleResult(
            shuffle_idx=0,
            shuffled_options=shuffled_options,
            model_output=LLMOutput(answer=selected_content),
            is_correct=is_correct,
            raw_response=llm_response
        )

    def evaluate_question(self, q: QuestionBase) -> QuestionEvaluationResult:
        original_options, correct_content = self._get_options_and_correct(q)

        shuffle_results = []
        is_strictly_correct = True
        total_score = 0.0


        for i in range(config.SHUFFLE_TRIALS):
            current_options = original_options.copy()
            rng = random.Random(f"{config.RANDOM_SEED}:{q.id}:{i}")
            rng.shuffle(current_options)

            prompt = PromptManager.construct_prompt(q.stem, current_options, q.qtype)
            messages = [
                {"role": "system", "content": PromptManager.get_system_prompt(q.qtype)},
                {"role": "user", "content": prompt}
            ]

            success = False
            last_error = None
            for attempt in range(3):
                try:
                    raw_data = llm_client.call_model(messages)
                    llm_output = LLMOutput(**raw_data)

                    selected_content = self._map_llm_answer_to_content(llm_output.answer, current_options)
                    is_correct, score = self._calculate_correctness_and_score(selected_content, correct_content, q.qtype)

                    sr = ShuffleResult(
                        shuffle_idx=i,
                        shuffled_options=current_options,
                        model_output=llm_output,
                        is_correct=is_correct,
                        raw_response=str(raw_data)
                    )
                    shuffle_results.append(sr)

                    if not is_correct:
                        is_strictly_correct = False

                    total_score += score
                    success = True
                    break

                except Exception as e:
                    last_error = e
                    print(f"Warning: Error evaluating Q {q.id} Shuffle {i} Attempt {attempt+1}: {e}")

            if not success:
                print(f"Failed Q {q.id} Shuffle {i} after 3 attempts. Raising error.")

                raise last_error

        correct_count = sum(1 for s in shuffle_results if s.is_correct)
        if correct_count == config.SHUFFLE_TRIALS:
            diff = "Easy"
        elif correct_count == 0:
            diff = "Hard"
        else:
            diff = "Medium"

        avg_score = total_score / float(config.SHUFFLE_TRIALS)

        return QuestionEvaluationResult(
            question_id=q.id,
            qtype=q.qtype,
            label=q.label,
            shuffle_results=shuffle_results,
            is_correct_strict=is_strictly_correct,
            score=avg_score,
            difficulty_level=diff
        )
