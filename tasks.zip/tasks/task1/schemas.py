from typing import List, Optional, Union, Dict, Any
from pydantic import BaseModel, Field
from enum import Enum

class QuestionType(str, Enum):
    SINGLE_CHOICE = "Single Choice"
    MULTIPLE_CHOICE = "Multiple Choice"
    TRUE_FALSE = "True/False"

class QuestionBase(BaseModel):
    id: Union[str, int]
    stem: str
    qtype: QuestionType
    label: Optional[str] = None
    source_instruction: Optional[str] = None

class SingleChoiceQuestion(QuestionBase):
    answer: str
    distractors: List[str]

class MultipleChoiceQuestion(QuestionBase):
    correct_options: List[str]
    distractors: List[str] = Field(default_factory=list)

class TrueFalseQuestion(QuestionBase):
    answer: str
    analysis: Optional[str] = None

class LLMOutput(BaseModel):
    analysis: Optional[str] = None
    answer: Union[str, List[str]]
    meta: Optional[Dict[str, Any]] = None

class ShuffleResult(BaseModel):
    shuffle_idx: int
    shuffled_options: List[str]
    model_output: LLMOutput
    is_correct: bool
    raw_response: str

class QuestionEvaluationResult(BaseModel):
    question_id: Union[str, int]
    qtype: QuestionType
    label: Optional[str]
    shuffle_results: List[ShuffleResult]
    is_correct_strict: bool
    score: float
    difficulty_level: str
