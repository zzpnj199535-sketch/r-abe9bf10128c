import os
from pathlib import Path
from typing import Optional


class Config:


    ROOT_DIR = Path(__file__).resolve().parent

    DEFAULT_MODEL = ""
    DEFAULT_BASE_URL = ""
    DEFAULT_API_KEY_ENV = ""

    _MODEL_NAME = DEFAULT_MODEL
    _BASE_URL = DEFAULT_BASE_URL
    _API_KEY_ENV = DEFAULT_API_KEY_ENV

    TEMPERATURE = 0.7
    TARGET_COUNTRY = "US"
    ENABLE_REASONING = True
    USE_CUSTOM_COT = False

    RETRY_ATTEMPTS = int(os.getenv("T1_RETRY_ATTEMPTS", "5"))
    RETRY_DELAY = float(os.getenv("T1_RETRY_DELAY", "5"))
    REQUEST_TIMEOUT = float(os.getenv("T1_REQUEST_TIMEOUT", "90"))

    SHUFFLE_TRIALS = 3
    RANDOM_SEED = 20260120

    DATA_PATH = ""
    OUTPUT_DIR = str(ROOT_DIR / "outputs")

    COUNTRY_CONTEXTS = {
        "US": "United States",
        "CN": "China",
    }

    @property
    def LLM_MODEL(self) -> str:
        if not self._MODEL_NAME:
            raise RuntimeError("Model is not configured.")
        return self._MODEL_NAME

    @property
    def LLM_BASE_URL(self) -> str:
        if not self._BASE_URL:
            raise RuntimeError("API base URL is not configured.")
        return self._BASE_URL

    @property
    def API_KEY_ENV(self) -> str:
        if not self._API_KEY_ENV:
            raise RuntimeError("API key environment variable name is not configured.")
        return self._API_KEY_ENV

    @property
    def LLM_API_KEY(self) -> str:
        variable_name = self.API_KEY_ENV
        value = os.getenv(variable_name)
        if not value:
            raise RuntimeError(
                f"Missing API key environment variable: {variable_name}"
            )
        return value

    def configure(
        self,
        *,
        model: Optional[str] = None,
        base_url: Optional[str] = None,
        api_key_env: Optional[str] = None,
        temperature: Optional[float] = None,
        target_country: Optional[str] = None,
        data_path: Optional[str] = None,
        output_dir: Optional[str] = None,
        seed: Optional[int] = None,
        shuffle_trials: Optional[int] = None,
    ) -> None:
        if model is not None:
            self._MODEL_NAME = model
        if base_url is not None:
            self._BASE_URL = base_url
        if api_key_env is not None:
            self._API_KEY_ENV = api_key_env
        if temperature is not None:
            self.TEMPERATURE = float(temperature)
        if target_country is not None:
            self.TARGET_COUNTRY = target_country
        if data_path is not None:
            self.DATA_PATH = data_path
        if output_dir is not None:
            self.OUTPUT_DIR = output_dir
        if seed is not None:
            self.RANDOM_SEED = int(seed)
        if shuffle_trials is not None:
            self.SHUFFLE_TRIALS = int(shuffle_trials)


config = Config()
