import argparse
import json
import os
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Iterable, List
from urllib.parse import urlparse

from config import config
from data_manager import DataManager
from evaluator import Evaluator
from schemas import QuestionBase, QuestionEvaluationResult


ROOT_DIR = Path(__file__).resolve().parent
DEFAULT_OUTPUT_ROOT = ROOT_DIR / "outputs"


def parse_args(argv=None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--context", choices=["US", "CN", "all"], default="all")
    parser.add_argument("--data", required=True)
    parser.add_argument("--temperature", type=float, choices=[0.0, 0.7], default=0.7)
    parser.add_argument("--model", default="")
    parser.add_argument("--base-url", default="")
    parser.add_argument("--api-key-env", default="")
    parser.add_argument("--limit-per-qtype", type=int, default=None)
    parser.add_argument("--seed", type=int, default=20260120)
    parser.add_argument("--shuffle-trials", type=int, default=3)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_ROOT))
    return parser.parse_args(argv)


def resolve_data_path(raw_path: str, argument_name: str) -> Path:
    if not raw_path.strip():
        raise ValueError(f"Missing required argument: {argument_name}")

    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        path = Path.cwd() / path
    try:
        path = path.resolve(strict=True)
    except (FileNotFoundError, OSError) as exc:
        raise ValueError(f"Data file does not exist for {argument_name}: {path}") from exc
    if not path.is_file():
        raise ValueError(f"Data path is not a file for {argument_name}: {path}")
    return path


def resolve_output_path(raw_path: str) -> Path:
    if not raw_path.strip():
        raise ValueError("Missing required argument: --output-dir")
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        path = Path.cwd() / path
    path = path.resolve()
    if path.exists() and not path.is_dir():
        raise ValueError(f"Output path exists but is not a directory: {path}")
    return path


def validate_runtime_inputs(args: argparse.Namespace) -> Path:
    errors = []
    args.model = args.model.strip()
    args.base_url = args.base_url.strip().rstrip("/")
    args.api_key_env = args.api_key_env.strip()

    if not args.model:
        errors.append("Missing required argument: --model")
    if not args.base_url:
        errors.append("Missing required argument: --base-url")
    else:
        parsed_url = urlparse(args.base_url)
        if parsed_url.scheme not in {"http", "https"} or not parsed_url.netloc:
            errors.append("--base-url must be an absolute HTTP(S) URL")
    if not args.api_key_env:
        errors.append("Missing required argument: --api-key-env")
    elif not os.getenv(args.api_key_env):
        errors.append(
            f"Missing API key environment variable: {args.api_key_env}"
        )
    if args.limit_per_qtype is not None and args.limit_per_qtype < 1:
        errors.append("--limit-per-qtype must be at least 1")
    if args.shuffle_trials < 1:
        errors.append("--shuffle-trials must be at least 1")
    if errors:
        raise ValueError("; ".join(errors))

    data_path = resolve_data_path(args.data, "--data")
    args.output_dir = str(resolve_output_path(args.output_dir))
    return data_path


def output_subdir(context: str, temperature: float) -> str:
    language = "EN" if context == "US" else "CN"
    temperature_label = "0" if temperature == 0.0 else "0.7"
    return f"output({language}-{temperature_label})"


def safe_model_name(model: str) -> str:
    model_name = model.split("/")[-1]
    safe_name = "".join(
        character
        for character in model_name
        if character.isalnum() or character in ("-", "_")
    )
    if not safe_name:
        raise ValueError("--model must contain at least one filename-safe character")
    return safe_name


def output_filename(model: str, context: str, temperature: float) -> str:
    suffix = "_".join(
        [
            safe_model_name(model),
            context,
            f"Reasoning{config.ENABLE_REASONING}",
            f"Temp{temperature}",
            f"CustomCoT{config.USE_CUSTOM_COT}",
        ]
    )
    return f"evaluation_details_{suffix}.jsonl"


def select_questions(
    questions: List[QuestionBase], limit_per_qtype: int | None
) -> List[QuestionBase]:
    if limit_per_qtype is None:
        return questions

    selected = []
    counts = defaultdict(int)
    for question in questions:
        if counts[question.qtype] >= limit_per_qtype:
            continue
        selected.append(question)
        counts[question.qtype] += 1
    return selected


def load_existing_results(path: Path) -> List[QuestionEvaluationResult]:
    results = []
    if not path.exists():
        return results

    print(f"Loading existing results from {path}...")
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                results.append(QuestionEvaluationResult(**json.loads(line)))
            except Exception as exc:
                print(f"Skipping invalid result at {path}:{line_number}: {exc}")
    return results


def process_single_question(question: QuestionBase, evaluator: Evaluator):
    try:
        return evaluator.evaluate_question(question)
    except Exception as exc:
        print(f"CRITICAL ERROR evaluating QID {question.id}: {exc}")
        return None


def write_run_config(path: Path, payload: dict) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)


def validate_resume_input_contract(
    run_config_path: Path,
    current_contract: dict,
    *,
    resume_state_exists: bool,
) -> None:

    if not run_config_path.exists():
        if resume_state_exists:
            raise ValueError(
                f"Cannot resume from {run_config_path.parent}: existing output "
                "state has no run_config.json with the M1 input contract. "
                "Use a new --output-dir."
            )
        return
    if not run_config_path.is_file():
        raise ValueError(f"Resume run_config path is not a file: {run_config_path}")

    try:
        with run_config_path.open("r", encoding="utf-8") as handle:
            previous_config = json.load(handle)
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(
            f"Cannot resume: invalid run_config.json at {run_config_path}: {exc}"
        ) from exc
    if not isinstance(previous_config, dict):
        raise ValueError(
            f"Cannot resume: run_config.json at {run_config_path} is not an object"
        )

    previous_contract = previous_config.get("input_contract")
    if not isinstance(previous_contract, dict):
        raise ValueError(
            f"Cannot resume: run_config.json at {run_config_path} is missing "
            "the required M1 input contract. Use a new --output-dir."
        )
    if previous_contract != current_contract:
        differing_fields = sorted(
            key
            for key in set(previous_contract).union(current_contract)
            if previous_contract.get(key) != current_contract.get(key)
        )
        raise ValueError(
            f"Cannot resume: M1 input contract mismatch at {run_config_path}; "
            f"differing fields: {differing_fields}. Use a new --output-dir."
        )


def run_context(
    context: str,
    questions: List[QuestionBase],
    data_path: Path,
    input_contract: dict,
    args: argparse.Namespace,
) -> dict:
    context_output_dir = Path(args.output_dir) / output_subdir(
        context, args.temperature
    )
    context_output_dir.mkdir(parents=True, exist_ok=True)

    config.configure(
        model=args.model,
        base_url=args.base_url,
        api_key_env=args.api_key_env,
        temperature=args.temperature,
        target_country=context,
        data_path=str(data_path),
        output_dir=str(context_output_dir),
        seed=args.seed,
        shuffle_trials=args.shuffle_trials,
    )

    details_name = output_filename(args.model, context, args.temperature)
    details_path = context_output_dir / details_name
    failed_path = context_output_dir / "failed_questions.log"
    run_config_path = context_output_dir / "run_config.json"

    if details_path.exists() and not args.resume:
        raise FileExistsError(
            f"{details_path} already exists. Use --resume or choose a new --output-dir."
        )
    if args.resume:
        validate_resume_input_contract(
            run_config_path,
            input_contract,
            resume_state_exists=details_path.exists() or failed_path.exists(),
        )

    selected_questions = select_questions(questions, args.limit_per_qtype)

    existing_results = load_existing_results(details_path) if args.resume else []
    source_ids = {str(question.id) for question in questions}
    incompatible_ids = [
        str(result.question_id)
        for result in existing_results
        if str(result.question_id) not in source_ids
    ]
    if incompatible_ids:
        preview = ", ".join(repr(question_id) for question_id in incompatible_ids[:5])
        if len(incompatible_ids) > 5:
            preview += ", ..."
        raise ValueError(
            f"Existing results at {details_path} are incompatible with the "
            f"current record IDs for context {context}: {preview}. "
            "Use a new --output-dir or remove the incompatible result file."
        )
    finished_ids = {str(result.question_id) for result in existing_results}
    tasks = [
        question
        for question in selected_questions
        if str(question.id) not in finished_ids
    ]

    run_config = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "context": context,
        "model": args.model,
        "base_url": args.base_url,
        "api_key_env": args.api_key_env,
        "temperature": args.temperature,
        "seed": args.seed,
        "shuffle_trials": args.shuffle_trials,
        "data_path": str(data_path),
        "output_dir": str(context_output_dir),
        "details_file": details_name,
        "source_question_count": len(questions),
        "selected_question_count": len(selected_questions),
        "already_finished_count": len(finished_ids),
        "pending_count": len(tasks),
        "input_contract_version": input_contract["contract_version"],
        "dataset_sha256": input_contract["dataset_sha256"],
        "answer_key_sha256": input_contract["answer_key_sha256"],
        "hydrated_dataset_sha256": input_contract["hydrated_dataset_sha256"],
        "answer_count": input_contract["answer_count"],
        "input_contract": input_contract,
    }
    write_run_config(run_config_path, run_config)

    print(f"\n=== M1 {context} ===")
    print(f"Data: {data_path}")
    print(f"Output: {details_path}")
    print(f"Selected records: {len(selected_questions)}; pending: {len(tasks)}")

    evaluator = Evaluator()
    if tasks:
        with details_path.open("a", encoding="utf-8") as handle:
            for index, question in enumerate(tasks, start=1):
                result = process_single_question(question, evaluator)
                if result is None:
                    with failed_path.open("a", encoding="utf-8") as failed:
                        failed.write(
                            f"{args.model} - QID {question.id} - returned None\n"
                        )
                    print(f"[{index}/{len(tasks)}] Failed QID {question.id}")
                    continue

                handle.write(result.model_dump_json() + "\n")
                handle.flush()
                existing_results.append(result)
                print(
                    f"[{index}/{len(tasks)}] Finished QID {question.id} "
                    f"({question.qtype}) - Correct: {result.is_correct_strict}"
                )

    return {
        "context": context,
        "data_path": str(data_path),
        "details_path": str(details_path),
        "source_question_count": len(questions),
        "selected_question_count": len(selected_questions),
        "result_count": len(existing_results),
        "failed_count": max(0, len(selected_questions) - len(existing_results)),
        "failed_log_exists": failed_path.exists(),
    }


def main(argv=None) -> int:
    args = parse_args(argv)
    try:
        data_path = validate_runtime_inputs(args)
    except ValueError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2

    summaries = []
    try:
        questions_by_context, input_contract = DataManager.load_questions_with_contract(
            data_path
        )
        contexts: Iterable[str] = (
            ["US", "CN"] if args.context == "all" else [args.context]
        )
        for context in contexts:
            summaries.append(
                run_context(
                    context,
                    questions_by_context[context],
                    data_path,
                    input_contract,
                    args,
                )
            )
    except Exception as exc:
        print(f"Run failed: {exc}", file=sys.stderr)
        return 1

    summary_path = Path(args.output_dir) / "task1_reproduction_summary.json"
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    with summary_path.open("w", encoding="utf-8") as handle:
        json.dump(summaries, handle, indent=2, ensure_ascii=False)
    print(f"\nSummary: {summary_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
