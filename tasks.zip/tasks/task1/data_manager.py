import hashlib
import json
from pathlib import Path
from typing import Dict, List, Type

from pydantic import ValidationError

from schemas import (
    MultipleChoiceQuestion,
    QuestionBase,
    SingleChoiceQuestion,
    TrueFalseQuestion,
)
from task1_answer_key import (
    ANSWER_KEY,
    ANSWER_KEY_COUNT,
    ANSWER_KEY_SHA256,
    INPUT_CONTRACT_VERSION,
    LEGACY_DATASET_SHA256,
    NEUTRAL_OPTIONS_VERSION,
    neutral_option_sort_key,
)


QUESTION_MODELS: Dict[str, Type[QuestionBase]] = {
    "Single Choice": SingleChoiceQuestion,
    "Multiple Choice": MultipleChoiceQuestion,
    "True/False": TrueFalseQuestion,
}

ID_PREFIX_TO_CONTEXT = {
    "CN": "CN",
    "EN": "US",
}

CN_QUESTION_COUNT = 1870
EN_QUESTION_COUNT = 716
TOTAL_QUESTION_COUNT = CN_QUESTION_COUNT + EN_QUESTION_COUNT

CHOICE_FIELDS = {"id", "stem", "qtype", "options"}
TRUE_FALSE_FIELDS = {"id", "stem", "qtype"}
FORBIDDEN_DATA_FIELDS = {
    "answer",
    "correct_options",
    "distractors",
}
VALID_TRUE_FALSE_ANSWERS = {"正确", "错误", "True", "False"}


def _expected_question_id(logical_row: int) -> str | None:
    if 1 <= logical_row <= CN_QUESTION_COUNT:
        return f"CN-{logical_row:04d}"
    if CN_QUESTION_COUNT < logical_row <= TOTAL_QUESTION_COUNT:
        en_row = logical_row - CN_QUESTION_COUNT
        return f"EN-{en_row:03d}"
    return None


def _jsonl_digest(records: List[dict]) -> str:
    digest = hashlib.sha256()
    for record in records:
        line = json.dumps(
            record,
            ensure_ascii=False,
            separators=(",", ":"),
        )
        digest.update(line.encode("utf-8"))
        digest.update(b"\n")
    return digest.hexdigest().upper()


class DataManager:
    @staticmethod
    def _validate_base_record(
        raw: dict,
        *,
        path: Path,
        line_number: int,
        expected_id: str,
        seen_ids: set[str],
    ) -> tuple[str, str]:
        location = f"{path}:{line_number}"
        if not isinstance(raw, dict):
            raise ValueError(
                f"Invalid record at {location}: each JSONL line must be a JSON object"
            )

        question_id = raw.get("id")
        if not isinstance(question_id, str) or not question_id:
            raise ValueError(
                f"Invalid record ID at {location}: got {question_id!r}; "
                f"expected {expected_id!r}"
            )
        if question_id in seen_ids:
            raise ValueError(f"Duplicate record ID at {location}: {question_id!r}")
        if question_id != expected_id:
            raise ValueError(
                f"Record ID sequence mismatch at {location}: got {question_id!r}; "
                f"expected {expected_id!r}"
            )

        stem = raw.get("stem")
        if not isinstance(stem, str) or not stem.strip():
            raise ValueError(
                f"Invalid stem at {location} for record {question_id!r}: "
                "expected a non-empty string"
            )

        qtype = raw.get("qtype")
        if qtype not in QUESTION_MODELS:
            raise ValueError(
                f"Unknown qtype at {location} for record {question_id!r}: {qtype!r}"
            )

        forbidden = sorted(FORBIDDEN_DATA_FIELDS.intersection(raw))
        if forbidden:
            raise ValueError(
                f"Answer-bearing fields are forbidden at {location} for "
                f"record {question_id!r}: {forbidden}"
            )
        return question_id, qtype

    @staticmethod
    def _hydrate_choice_record(
        raw: dict,
        entry: dict,
        *,
        path: Path,
        line_number: int,
        question_id: str,
        qtype: str,
    ) -> tuple[dict, dict]:
        location = f"{path}:{line_number}"
        if set(raw) != CHOICE_FIELDS:
            raise ValueError(
                f"Invalid fields at {location} for {question_id!r}: got "
                f"{sorted(raw)}, expected {sorted(CHOICE_FIELDS)}"
            )

        options = raw.get("options")
        expected_option_count = 4 if qtype == "Single Choice" else 5
        if not isinstance(options, list) or len(options) != expected_option_count:
            raise ValueError(
                f"Invalid options at {location} for {question_id!r}: expected "
                f"a list of exactly {expected_option_count} options"
            )
        if any(not isinstance(option, str) or not option.strip() for option in options):
            raise ValueError(
                f"Invalid options at {location} for {question_id!r}: every option "
                "must be a non-empty string"
            )
        if len(options) != len(set(options)):
            raise ValueError(
                f"Duplicate options at {location} for record {question_id!r}"
            )

        option_hashes = [
            neutral_option_sort_key(question_id, option) for option in options
        ]
        if len(option_hashes) != len(set(option_hashes)):
            raise ValueError(
                f"Neutral option SHA256 collision at {location} for {question_id!r}"
            )
        neutral_options = sorted(
            options,
            key=lambda option: neutral_option_sort_key(question_id, option),
        )
        if options != neutral_options:
            raise ValueError(
                f"Non-neutral option order at {location} for {question_id!r}; "
                f"expected {NEUTRAL_OPTIONS_VERSION} SHA256 order"
            )

        expected_entry_fields = {"qtype", "correct_indices", "legacy_order"}
        if not isinstance(entry, dict) or set(entry) != expected_entry_fields:
            raise ValueError(
                f"Invalid reference-map fields for {question_id!r}: expected "
                f"{sorted(expected_entry_fields)}"
            )
        if entry.get("qtype") != qtype:
            raise ValueError(
                f"Reference-map type mismatch for {question_id!r}: "
                f"{entry.get('qtype')!r} != {qtype!r}"
            )

        correct_indices = entry.get("correct_indices")
        legacy_order = entry.get("legacy_order")
        if not isinstance(correct_indices, list) or any(
            type(index) is not int for index in correct_indices
        ):
            raise ValueError(
                f"Invalid correct_indices in reference map for {question_id!r}"
            )
        expected_correct_count = (
            {1} if qtype == "Single Choice" else {2, 3, 4, 5}
        )
        if len(correct_indices) not in expected_correct_count:
            raise ValueError(
                f"Invalid correct_indices length for {question_id!r}: "
                f"{len(correct_indices)}"
            )
        if correct_indices != sorted(correct_indices) or len(correct_indices) != len(
            set(correct_indices)
        ):
            raise ValueError(
                f"correct_indices must be unique and ascending for {question_id!r}"
            )
        if any(index < 0 or index >= len(options) for index in correct_indices):
            raise ValueError(
                f"correct_indices out of range for record {question_id!r}"
            )

        if not isinstance(legacy_order, list) or any(
            type(index) is not int for index in legacy_order
        ):
            raise ValueError(f"Invalid legacy_order in reference map for {question_id!r}")
        if sorted(legacy_order) != list(range(len(options))):
            raise ValueError(
                f"legacy_order is not a complete permutation for {question_id!r}"
            )
        correct_count = len(correct_indices)
        if set(legacy_order[:correct_count]) != set(correct_indices):
            raise ValueError(
                f"legacy_order correct-option prefix mismatch for {question_id!r}"
            )

        legacy_options = [options[index] for index in legacy_order]
        if qtype == "Single Choice":
            hydrated = {
                "id": question_id,
                "stem": raw["stem"],
                "qtype": qtype,
                "answer": legacy_options[0],
                "distractors": legacy_options[1:],
            }
            legacy_record = dict(hydrated)
        else:
            hydrated = {
                "id": question_id,
                "stem": raw["stem"],
                "qtype": qtype,
                "correct_options": legacy_options[:correct_count],
                "distractors": legacy_options[correct_count:],
            }
            legacy_record = dict(hydrated)
        return hydrated, legacy_record

    @staticmethod
    def _hydrate_true_false_record(
        raw: dict,
        entry: dict,
        *,
        path: Path,
        line_number: int,
        question_id: str,
        qtype: str,
    ) -> tuple[dict, dict]:
        location = f"{path}:{line_number}"
        if set(raw) != TRUE_FALSE_FIELDS:
            raise ValueError(
                f"Invalid fields at {location} for {question_id!r}: got "
                f"{sorted(raw)}, expected {sorted(TRUE_FALSE_FIELDS)}"
            )
        expected_entry_fields = {"qtype", "answer"}
        if not isinstance(entry, dict) or set(entry) != expected_entry_fields:
            raise ValueError(
                f"Invalid reference-map fields for {question_id!r}: expected "
                f"{sorted(expected_entry_fields)}"
            )
        if entry.get("qtype") != qtype:
            raise ValueError(
                f"Reference-map type mismatch for {question_id!r}: "
                f"{entry.get('qtype')!r} != {qtype!r}"
            )
        answer = entry.get("answer")
        if answer not in VALID_TRUE_FALSE_ANSWERS:
            raise ValueError(
                f"Invalid True/False value in reference map for {question_id!r}: "
                f"{answer!r}"
            )
        hydrated = {
            "id": question_id,
            "stem": raw["stem"],
            "qtype": qtype,
            "answer": answer,
        }
        return hydrated, dict(hydrated)

    @classmethod
    def _load(
        cls,
        file_path: str | Path,
    ) -> tuple[Dict[str, List[QuestionBase]], dict]:
        path = Path(file_path)
        if not path.is_file():
            raise FileNotFoundError(f"Data file not found: {path}")

        questions_by_context: Dict[str, List[QuestionBase]] = {
            "US": [],
            "CN": [],
        }
        seen_ids: set[str] = set()
        legacy_records: List[dict] = []
        with path.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                expected_id = _expected_question_id(line_number)
                if expected_id is None:
                    raise ValueError(
                        f"Unexpected extra JSONL line at {path}:{line_number}; "
                        f"expected end of file after EN-{EN_QUESTION_COUNT:03d}"
                    )
                if not line.strip():
                    raise ValueError(
                        f"Blank JSONL line at {path}:{line_number}; expected "
                        f"record ID {expected_id!r}"
                    )
                try:
                    raw = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(
                        f"Invalid JSON at {path}:{line_number}: {exc.msg}"
                    ) from exc

                question_id, qtype = cls._validate_base_record(
                    raw,
                    path=path,
                    line_number=line_number,
                    expected_id=expected_id,
                    seen_ids=seen_ids,
                )
                entry = ANSWER_KEY.get(question_id)
                if entry is None:
                    raise ValueError(
                        f"Missing program reference for record {question_id!r}"
                    )

                if qtype == "True/False":
                    hydrated, legacy_record = cls._hydrate_true_false_record(
                        raw,
                        entry,
                        path=path,
                        line_number=line_number,
                        question_id=question_id,
                        qtype=qtype,
                    )
                else:
                    hydrated, legacy_record = cls._hydrate_choice_record(
                        raw,
                        entry,
                        path=path,
                        line_number=line_number,
                        question_id=question_id,
                        qtype=qtype,
                    )

                model = QUESTION_MODELS[qtype]
                try:
                    question = model(**hydrated)
                except ValidationError as exc:
                    raise ValueError(
                        f"Invalid M1 record at {path}:{line_number} "
                        f"for {question_id!r}: {exc}"
                    ) from exc

                seen_ids.add(question_id)
                legacy_records.append(legacy_record)
                context = ID_PREFIX_TO_CONTEXT[question_id[:2]]
                questions_by_context[context].append(question)

        actual_count = len(seen_ids)
        if actual_count != TOTAL_QUESTION_COUNT:
            expected_id = _expected_question_id(actual_count + 1)
            raise ValueError(
                f"Unexpected end of file at {path} after logical row "
                f"{actual_count}; expected record ID {expected_id!r} at "
                f"logical row {actual_count + 1}"
            )

        answer_ids = set(ANSWER_KEY)
        if len(ANSWER_KEY) != ANSWER_KEY_COUNT or answer_ids != seen_ids:
            missing = sorted(seen_ids - answer_ids)
            extra = sorted(answer_ids - seen_ids)
            raise ValueError(
                "M1 data/reference-map coverage mismatch: "
                f"missing={missing[:5]}, extra={extra[:5]}, "
                f"data_count={len(seen_ids)}, answer_count={len(answer_ids)}"
            )

        hydrated_sha256 = _jsonl_digest(legacy_records)
        if hydrated_sha256 != LEGACY_DATASET_SHA256:
            raise ValueError(
                "M1 reference-data hash mismatch: "
                f"{hydrated_sha256} != {LEGACY_DATASET_SHA256}"
            )

        contract = {
            "contract_version": INPUT_CONTRACT_VERSION,
            "neutral_options_version": NEUTRAL_OPTIONS_VERSION,
            "dataset_sha256": hashlib.sha256(path.read_bytes()).hexdigest().upper(),
            "answer_key_sha256": ANSWER_KEY_SHA256,
            "hydrated_dataset_sha256": hydrated_sha256,
            "question_count": actual_count,
            "answer_count": len(answer_ids),
        }
        return questions_by_context, contract

    @classmethod
    def load_questions_by_context(
        cls,
        file_path: str | Path,
    ) -> Dict[str, List[QuestionBase]]:
        questions_by_context, _ = cls._load(file_path)
        return questions_by_context

    @classmethod
    def load_questions_with_contract(
        cls,
        file_path: str | Path,
    ) -> tuple[Dict[str, List[QuestionBase]], dict]:
        return cls._load(file_path)

    @classmethod
    def build_input_contract(cls, file_path: str | Path) -> dict:
        _, contract = cls._load(file_path)
        return contract
