import json
import re
import time
from typing import Any, Dict, List, Optional

import requests

from config import config


class LLMClient:
    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {config.LLM_API_KEY}",
            "Content-Type": "application/json",
        }

    def _extract_xml_json(self, text: str) -> Dict[str, Any]:
        def clean_json_str(s: str) -> str:
            return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", s)

        candidates = []
        match = re.search(
            r"<task_output[^>]*>\s*(.*?)\s*</task_output>",
            text,
            re.DOTALL | re.IGNORECASE,
        )
        if match:
            candidates.append(match.group(1).strip())

        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1 and end > start:
            candidates.append(text[start : end + 1].strip())

        for json_str in candidates:
            try:
                return json.loads(clean_json_str(json_str), strict=False)
            except json.JSONDecodeError:
                continue

        return {"analysis": None, "answer": text.strip()}

    def call_model(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
    ) -> Dict[str, Any]:
        if temperature is None:
            temperature = config.TEMPERATURE

        payload = {
            "model": config.LLM_MODEL,
            "messages": messages,
            "temperature": temperature,
            "stream": False,
        }

        last_error = None
        for attempt in range(config.RETRY_ATTEMPTS):
            try:
                response = requests.post(
                    f"{config.LLM_BASE_URL.rstrip('/')}/chat/completions",
                    headers=self._headers(),
                    json=payload,
                    timeout=config.REQUEST_TIMEOUT,
                )
                response.raise_for_status()
                result = response.json()
                content = result["choices"][0]["message"]["content"]
                return self._extract_xml_json(content)
            except (requests.RequestException, KeyError, ValueError, json.JSONDecodeError) as exc:
                last_error = exc
                print(f"Attempt {attempt + 1} failed: {exc}")
                if attempt < config.RETRY_ATTEMPTS - 1:
                    time.sleep(config.RETRY_DELAY)

        raise RuntimeError(
            f"LLM call failed after {config.RETRY_ATTEMPTS} attempts: {last_error}"
        )


llm_client = LLMClient()
