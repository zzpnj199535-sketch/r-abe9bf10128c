from config import config
from schemas import QuestionType


class PromptManager:
    @staticmethod
    def _region_name(target_country=None) -> str:
        country = target_country if target_country is not None else config.TARGET_COUNTRY
        return config.COUNTRY_CONTEXTS.get(country, country)

    @staticmethod
    def _normalize_qtype(qtype) -> QuestionType:
        if isinstance(qtype, QuestionType):
            return qtype
        return QuestionType(qtype)

    @staticmethod
    def build_system_prompt(
        qtype=None,
        target_country=None,
        enable_reasoning=None,
        use_custom_cot=None,
    ) -> str:

        question_type = (
            PromptManager._normalize_qtype(qtype)
            if qtype is not None
            else QuestionType.SINGLE_CHOICE
        )
        target_region = PromptManager._region_name(target_country)
        reasoning = config.ENABLE_REASONING if enable_reasoning is None else enable_reasoning

        if question_type == QuestionType.SINGLE_CHOICE:
            task_desc = "single-select multiple-choice questions"
            answer_spec = 'A single string representing your final choice, e.g., "Option A".'
            example_answer = '"Option A"'
            analysis_target = "the question and the available options"
            reasoning_target = "choice"
            example_analysis = (
                "Here is the detailed reasoning explaining why the specific option "
                "is correct and why the others are incorrect..."
            )
        elif question_type == QuestionType.MULTIPLE_CHOICE:
            task_desc = "multi-select multiple-choice questions"
            answer_spec = 'A JSON array of selected options, e.g., ["Option A", "Option C"].'
            example_answer = '["Option A", "Option C"]'
            analysis_target = "the question and the available options"
            reasoning_target = "choice"
            example_analysis = (
                "Here is the detailed reasoning explaining why the specific options "
                "are correct and why the others are incorrect..."
            )
        elif question_type == QuestionType.TRUE_FALSE:
            task_desc = "true/false judgment questions"
            answer_spec = 'A single string representing your final judgment, i.e., "True" or "False".'
            example_answer = '"True"'
            analysis_target = "the statement"
            reasoning_target = "judgment"
            example_analysis = (
                "Here is the detailed reasoning explaining why the statement is true or false..."
            )
        else:
            raise ValueError(f"Unsupported question type: {question_type}")

        reasoning_line = (
            f"Before providing the final answer, you must provide a comprehensive "
            f"analysis of {analysis_target}, explaining the logic behind your {reasoning_target}."
            if reasoning
            else "Provide the final answer according to the requested JSON schema."
        )

        return f"""
You are an expert in {target_region} technology transfer, specifically acting as a seasoned technology manager. You are tasked with answering {task_desc} related to this domain.
{reasoning_line}
You MUST format your entire response strictly as a valid JSON object, enclosed within <task_output> tags.
The JSON object must contain exactly two keys:
- "analysis": A string containing your step-by-step reasoning.
- "answer": {answer_spec}

Example format:
<task_output>
{{
  "analysis": "{example_analysis}",
  "answer": {example_answer}
}}
</task_output>
""".strip()

    @staticmethod
    def get_system_prompt(qtype=None):
        return PromptManager.build_system_prompt(qtype=qtype)

    @staticmethod
    def format_options(options: list) -> str:
        chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        result = []
        for i, opt in enumerate(options):
            if i < len(chars):
                result.append(f"{chars[i]}. {opt}")
        return "\n".join(result)

    @staticmethod
    def construct_prompt(stem: str, options: list, qtype) -> str:
        formatted_options = PromptManager.format_options(options)
        question_type = PromptManager._normalize_qtype(qtype)
        if question_type == QuestionType.TRUE_FALSE:
            return f"Statement: {stem}\n\nOptions:\n{formatted_options}\n\nQuestion Type: {question_type.value}"
        return f"Question: {stem}\n\nOptions:\n{formatted_options}\n\nQuestion Type: {question_type.value}"
