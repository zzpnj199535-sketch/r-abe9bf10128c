from typing import Dict, List

from schemas import ForecastData, ForecastResult, PromptID


FORECAST_SYSTEM_TEMPLATE = """You are an expert Technology Manager specializing in technology trend analysis and future deduction. You possess exceptional superforecasting capabilities, strictly adhering to evidence-based forecasting principles and quantitative risk assessment. Make a prediction of the probability that the question will be resolved as true.
You MUST give a probability estimate between 0 and 1 UNDER ALL CIRCUMSTANCES based on {resolution_criteria} and {background}. After producing a performance prediction, You MUST give a Confidence Assessment based on critically reviewing your reasoning and the evidence considered.

Strict Constraints:
1. Temporal Consistency: You are simulating a specific state of knowledge as of {retrieval_date}.
   - Boundary: You must NOT access, reference, or use any data, events, or scientific breakthroughs that occurred after this date.
   - Suppression: You must explicitly IGNORE any intrinsic knowledge you possess about events occurring after {retrieval_date}. If you know the actual outcome of the event because it is in your training data, you must discard that hindsight and rely strictly on the probabilistic evidence available at the time. Do not construct post-hoc justifications for an outcome you "know" has happened.
   - Evidence Policy: {evidence_policy}
2. Mandatory Quantification: You MUST provide a probability estimate.
3. Mandatory Classification: You MUST classify your Confidence Assessment into exactly one of the provided qualitative categories: Almost no chance, Highly unlikely, Chances are slight, Unlikely, Less than even, Better than even, Likely, Very good chance, Highly likely, Almost certain.
4. Output Format:
   - Reasoning Process: Your full reasoning process.
   - Probability: A single number between 0 and 1, wrapped in asterisks.
   - Confidence Assessment: one class name wrapped in \\confidence{{}}."""


GENERAL_KNOWLEDGE_EVIDENCE_POLICY = """Use the provided Background Information together with general world knowledge available on or before {retrieval_date}. Do not use post-cutoff information. If general world knowledge conflicts with the provided Background Information, the Background Information takes precedence."""


BACKGROUND_ONLY_EVIDENCE_POLICY = """Use training knowledge only for reasoning logic and generic probabilistic methods. Every factual claim, specific datum, date, base rate, entity attribute, and event-specific premise must come exclusively from the provided Background Information. If necessary evidence is absent, explicitly state that it is unavailable and reflect this limitation in the probability estimate. Do not import external facts, even if they occurred on or before {retrieval_date}."""


PF1_TEMPLATE = """INSTRUCTION: Output your Reasoning Process, Probability and Confidence Assessment."""


PF2_TEMPLATE = """INSTRUCTIONS:
1. Given the above question, rephrase and expand it to help you answer more effectively. Maintain all information in the original question.
2. Using your knowledge of the world and topic, as well as the information provided, provide a few reasons why the answer might be no. Rate the strength of each reason.
3. Using your knowledge of the world and topic, as well as the information provided, provide a few reasons why the answer might be yes. Rate the strength of each reason.
4. Aggregate your considerations. Think like a superforecaster (e.g., Nate Silver).
5. Output an initial probability (prediction) given steps 1-4.
6. Evaluate whether your calculated probability is excessively confident or not confident enough. Also, consider anything else that might affect the forecast that you did not previously consider (e.g., base rate of the event). Determine your confidence level based on the provided categories.
7. Output your Reasoning Process, Probability and Confidence Assessment."""


PF3_TEMPLATE = """INSTRUCTIONS:
1. Given the above question, rephrase and expand it to help you answer more effectively. Maintain all information in the original question.
2. Analyze the provided Background text to provide a few reasons why the answer might be no.
   - Constraint: You may use your training for reasoning logic, but all evidence, specific data, and entity attributes must come exclusively from the provided Background.
   - Negative Constraint: Do not use external knowledge to import facts, reputations, or psychological traits (e.g., "impulsive," "firefighting") unless explicitly described in the text.
   - Uncertainty: Explicitly label ambiguous information or rumors found in the text as such; do not attempt to resolve them with external knowledge.
   - Rate the strength of each reason based on the evidence provided.
3. Analyze the provided Background text to provide a few reasons why the answer might be yes.
   - Constraint: Adhere to the same strict evidence constraints as mentioned above. Do not hallucinate external facts or industry averages.
   - Entity Verification: Verify all entity-claim links against the text. Do not default to the most famous entity associated with a topic (e.g., do not attribute a report to a major org if the text specifies a different one).
   - Rate the strength of each reason based on the evidence provided.
4. Aggregate your considerations. Think like a superforecaster (e.g., Nate Silver).
   - Source Integrity: Do not capitalize phrases to look like document titles (e.g., "The 2025 Reliability Report") unless they appear verbatim in the text.
   - Weigh the evidence found in the Background to form a balanced view.
5. Output an initial probability (prediction) given the preceding analysis.
6. Evaluate your confidence.
   - Base Rates: derive base rates only from historical data explicitly present in the Background. If no relevant historical data is present, state that no base rate is available. Do not invent "standard industry practices" or "comparable events."
   - Consider if the evidence in the text is sufficient or conflicting. Determine your confidence level based on the provided categories.
7. Output your Reasoning Process, Probability and Confidence Assessment."""


JUDGE_RUBRIC = """A: Context fidelity
1 - Terrible: Severe detachment. Reasoning relies entirely on fabricated evidence or assumptions contradicting the provided context.
2 - Poor: Contains clear factual errors, misrepresentations of the source, or introduces unsupported claims that skew the analysis.
3 - Adequate: Basic compliance. Relies on the provided materials to formulate a correct baseline answer but may miss subtle nuances. Minor, non-critical extrapolations may be present.
4 - Good: High fidelity. All major claims are correctly sourced. Paraphrases effectively while maintaining strict factual accuracy. Does not explicitly critique the source material's limitations.
5 - Exceptional: Perfect fidelity. Every factual claim is explicitly anchored to specific source material. Demonstrates "extreme ownership" by identifying and flagging internal inconsistencies or ambiguities within the materials themselves. Zero ungrounded extrapolation.

B: Evidence extraction
1 - Terrible: Evidence extracted is entirely irrelevant, trivial, or misses the core predictive task.
2 - Poor: Incomplete or superficial extraction. Fails to distinguish critical predictive signals from peripheral information.
3 - Adequate: Extracts surface-level, obvious evidence. Prioritization is often based on narrative sequence rather than predictive impact.
4 - Good: Comprehensive extraction of all critical explicit evidence. Demonstrates strong understanding of relative importance (signal vs. noise) but does not fully articulate structural missing information.
5 - Exceptional: Extracts explicit evidence and accurately infers latent variables/causal mechanisms. Actively seeks disconfirming evidence. Explicitly identifies what key missing information would decisively shift the prediction.

C: Logical combination
1 - Terrible: No coherent reasoning structure. The argumentative logic is fundamentally flawed or self-contradictory.
2 - Poor: Disjointed listing of points with minimal synthesis. No clear or logical argumentative thread connecting the variables.
3 - Adequate: Linear listing and brief discussion of evidence. The "synthesis" is merely a summary of points. Weights are implied only by sequence or text emphasis.
4 - Good: Clear logical argument with an implicit weighting structure. Explains why evidence matters and how it combines qualitatively (e.g., "A strongly supports, but B tempers"). Coherent argumentative thread.
5 - Exceptional: Transparent, step-by-step synthesis. Explains the interactive effects of evidence (e.g., how Risk A neutralizes Signal B). Explicitly defines the directional impact of each key variable on the outcome, forming a cohesive, logically rigorous narrative prior to assigning numbers.

D: Uncertainty consideration
1 - Terrible: Presents a strictly deterministic, single-path narrative with zero acknowledgment of alternative possibilities.
2 - Poor: Token, superficial acknowledgment of uncertainty (e.g., a boilerplate disclaimer that "nothing is certain").
3 - Adequate: Acknowledges generic uncertainties (e.g., "market conditions could change"). Treatment of risk is basic and checklist-like.
4 - Good: Identifies and explores major known unknowns and standard counter-arguments. Discusses how specific uncertainties could alter the outcome.
5 - Exceptional: Conducts a rigorous "pre-mortem." Constructs plausible, specific failure scenarios that are not mere negations of the main forecast. Explores second-order effects (e.g., "Event A triggers B, making C likely"). Distinguishes clearly between epistemic limits and aleatory randomness.

E: Probability
1 - Terrible: The probability is internally inconsistent with the text, completely unjustified, or mathematically impossible given the stated premises.
2 - Poor: The probability appears plucked from thin air, with minimal linkage to the severity or weight of the evidence discussed.
3 - Adequate: The probability is loosely connected to the text. The jump from qualitative discussion to the specific final number feels somewhat arbitrary.
4 - Good: The probability is well-justified and aligned with the qualitative analysis. The link from argument to number is clear, though the mapping relies slightly on intuitive estimation rather than strict formal updating.
5 - Exceptional: The final probability is the direct, unavoidable output of the stated logic. Provides a complete, falsifiable audit trail (e.g., pseudo-Bayesian updating from a stated prior). The justification firmly withstands a "why not +/- 10%?" challenge.

Scoring philosophy and aggregation rule
1. The "5" is Sacred: A score of 5 represents superforecaster-level analytical rigor. It must be earned through explicit causal reasoning, deep structural logic, and total mathematical transparency.
2. "3" is the Competent Baseline: A score of 3 represents a solid, instruction-following response without major errors. It is the benchmark for standard capability.
3. The Failure Floor: Any forecast whose internal logic or probability mapping is so fundamentally broken that it guarantees performance worse than random guessing - specifically, a predictive rationale that would mathematically yield a Brier Score > 0.25 in binary forecasting - must immediately receive a score of 1 in Dimension C and Dimension E.
4. Aggregation rule: (1) The Overall Score is not a simple unconstrained average. Dimension A serves as an absolute epistemic baseline. (2) Veto Condition: If Dimension A is scored <= 2, the Overall Score is capped at 2, regardless of performance in other dimensions (a perfectly reasoned argument based on hallucinations is scientifically invalid). (3) Standard Aggregation: If Dimension A is >= 3, the Overall Score is calculated as an evenly weighted average: Overall = (A + B + C + D + E) / 5. (4) Rounding Rule: To map the overall performance back to the qualitative 1-5 tier system, the standard aggregation score is rounded to the nearest whole integer."""


class PromptManager:
    PROMPT_TEMPLATES: Dict[PromptID, str] = {
        "PF1": PF1_TEMPLATE,
        "PF2": PF2_TEMPLATE,
        "PF3": PF3_TEMPLATE,
    }
    JUDGE_SYSTEM_PROMPT = (
        "You are an objective and highly analytical judge assistant. Your core "
        "philosophy is to evaluate logic strictly, fairly, and without score "
        "inflation."
    )
    JUDGE_PROTOCOL = "appendix_s3_json"

    @staticmethod
    def candidate_system_prompt(
        background: str,
        resolution_criteria: str,
        retrieval_date: str,
        prompt_id: PromptID,
    ) -> str:
        if prompt_id in ("PF1", "PF2"):
            policy_template = GENERAL_KNOWLEDGE_EVIDENCE_POLICY
        elif prompt_id == "PF3":
            policy_template = BACKGROUND_ONLY_EVIDENCE_POLICY
        else:
            raise ValueError(f"Unsupported prompt ID: {prompt_id}")

        return FORECAST_SYSTEM_TEMPLATE.format(
            background=background,
            resolution_criteria=resolution_criteria,
            retrieval_date=retrieval_date,
            evidence_policy=policy_template.format(retrieval_date=retrieval_date),
        )

    @classmethod
    def candidate_user_prompt(
        cls,
        question: str,
        background: str,
        resolution_criteria: str,
        retrieval_date: str,
        prompt_id: PromptID,
    ) -> str:
        return (
            f"QUESTION: {question}\n"
            f"BACKGROUND: {background}\n"
            f"RESOLUTION CRITERIA: {resolution_criteria}\n"
            f"RETRIEVAL DATE: {retrieval_date}\n\n"
            f"{cls.PROMPT_TEMPLATES[prompt_id]}"
        )

    @classmethod
    def candidate_messages(
        cls, item: ForecastData, prompt_id: PromptID
    ) -> List[Dict[str, str]]:
        return [
            {
                "role": "system",
                "content": cls.candidate_system_prompt(
                    item.background,
                    item.resolution_criteria,
                    item.retrieval_date,
                    prompt_id,
                ),
            },
            {
                "role": "user",
                "content": cls.candidate_user_prompt(
                    item.question,
                    item.background,
                    item.resolution_criteria,
                    item.retrieval_date,
                    prompt_id,
                ),
            },
        ]

    @staticmethod
    def judge_prompt(result: ForecastResult) -> str:
        return f"""TASK: Use the provided Rubric to evaluate the reasoning quality of the candidate LLM response against the provided Question, Background, Resolution Criteria, and Retrieval Date. Return a JSON object with two fields: "Score" (integer 1-5) and "Feedback" (an evidence-backed justification).

INPUT:
Question: {result.question}
Background: {result.background}
Resolution Criteria: {result.resolution_criteria}
Retrieval Date: {result.retrieval_date}
Candidate LLM Response: {result.reasoning_eval}

RUBRIC:
{JUDGE_RUBRIC}"""
