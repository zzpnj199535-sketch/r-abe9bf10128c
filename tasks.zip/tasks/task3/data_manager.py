import json
import hashlib
from pathlib import Path
from typing import List

from pydantic import ValidationError

from schemas import ForecastData, ForecastItem
from task3_answer_key import (
    QUESTION_ID_BY_SHA256,
    QUESTION_RESOLUTION_BY_SHA256,
    validate_answer_key,
    validate_identity_map,
)


class DataManager:
    @staticmethod
    def question_sha256(question: str) -> str:
        return hashlib.sha256(question.encode("utf-8")).hexdigest().upper()

    @staticmethod
    def load_data(file_path: str | Path) -> List[ForecastItem]:
        answer_key_sha256 = validate_answer_key()
        identity_map_sha256 = validate_identity_map()
        path = Path(file_path)
        if not path.is_file():
            raise FileNotFoundError(f"Data file not found: {path}")

        items: List[ForecastItem] = []
        seen_ids = set()
        seen_question_keys = set()
        with path.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                if not line.strip():
                    continue
                try:
                    raw = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(
                        f"Invalid JSON at {path}:{line_number}: {exc.msg}"
                    ) from exc
                try:
                    question = ForecastData(**raw)
                except ValidationError as exc:
                    raise ValueError(
                        f"Invalid M3 record at {path}:{line_number}: {exc}"
                    ) from exc
                if question.id in seen_ids:
                    raise ValueError(
                        f"Duplicate M3 ID at {path}:{line_number}: {question.id}"
                    )
                question_key = DataManager.question_sha256(question.question)
                if question_key in seen_question_keys:
                    raise ValueError(
                        "Duplicate M3 record at "
                        f"{path}:{line_number}: {question.question!r}"
                    )
                if question_key not in QUESTION_RESOLUTION_BY_SHA256:
                    raise ValueError(
                        "M3 record has no exact reference-map match at "
                        f"{path}:{line_number}: {question.question!r}"
                    )
                expected_id = QUESTION_ID_BY_SHA256.get(question_key)
                if expected_id != question.id:
                    raise ValueError(
                        "M3 ID does not match the exact formal record identity at "
                        f"{path}:{line_number}: id={question.id!r}, "
                        f"expected={expected_id!r}"
                    )
                resolution = QUESTION_RESOLUTION_BY_SHA256[question_key]
                item = ForecastItem(
                    **question.model_dump(),
                    resolution=resolution,
                    resolution_answer="YES" if resolution == 1 else "NO",
                )
                seen_ids.add(item.id)
                seen_question_keys.add(question_key)
                items.append(item)

        if not items:
            raise ValueError(f"Data file contains no M3 records: {path}")
        missing_question_keys = set(QUESTION_RESOLUTION_BY_SHA256) - seen_question_keys
        if missing_question_keys:
            raise ValueError(
                "M3 data does not exactly cover the program reference map: "
                f"missing {len(missing_question_keys)} record(s); "
                f"answer_key_sha256={answer_key_sha256}, "
                f"identity_map_sha256={identity_map_sha256}"
            )
        return items
