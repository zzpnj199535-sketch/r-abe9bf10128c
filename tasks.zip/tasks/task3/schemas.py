from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


PromptID = Literal["PF1", "PF2", "PF3"]
JudgeParseFormat = Literal["json", "prometheus_result"]
JudgeProtocolID = Literal["appendix_s3_json"]
ConfidenceCategory = Literal[
    "Almost no chance",
    "Highly unlikely",
    "Chances are slight",
    "Unlikely",
    "Less than even",
    "Better than even",
    "Likely",
    "Very good chance",
    "Highly likely",
    "Almost certain",
]


def parse_iso_datetime(value: str, field_name: str) -> datetime:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (AttributeError, TypeError, ValueError) as exc:
        raise ValueError(f"{field_name} must be an ISO-8601 datetime: {value!r}") from exc


class ForecastData(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: str = Field(min_length=1)
    question: str = Field(min_length=1)
    background: str = Field(min_length=1)
    resolution_criteria: str = Field(min_length=1)
    retrieval_date: str = Field(min_length=1)

    @field_validator("retrieval_date")
    @classmethod
    def validate_retrieval_date(cls, value: str) -> str:
        parse_iso_datetime(value, "retrieval_date")
        return value


class ForecastItem(ForecastData):


    resolution: Literal[0, 1]
    resolution_answer: Literal["YES", "NO"]


class ForecastResult(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str = Field(min_length=1)
    question: str = Field(min_length=1)
    background: str = Field(min_length=1)
    resolution_criteria: str = Field(min_length=1)
    retrieval_date: str = Field(min_length=1)
    reasoning_eval: str = Field(min_length=1)
    confidence_assessment: ConfidenceCategory
    confidence_score: float = Field(ge=0.0, le=1.0)
    probability: float = Field(ge=0.0, le=1.0)
    resolution: Literal[0, 1]
    resolution_answer: Literal["YES", "NO"]
    brier_score: float = Field(ge=0.0, le=1.0)
    accuracy: Literal[0, 1]
    prompt_id: PromptID
    reasoning_score: Optional[int] = Field(default=None, ge=1, le=5)
    reasoning_feedback: Optional[str] = None
    raw_judge_response: Optional[str] = None
    judge_parse_format: Optional[JudgeParseFormat] = None
    judge_protocol: Optional[JudgeProtocolID] = None
