import argparse
import hashlib
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional
from urllib.parse import urlparse

from config import APISettings
from data_manager import DataManager
from evaluator import CandidateEvaluator, ReasoningJudge
from llm_client import LLMClient
from prompts import PromptManager
from schemas import ForecastResult, PromptID
from task3_answer_key import (
    ANSWER_COUNT,
    INPUT_CONTRACT_VERSION,
    QUESTION_ID_BY_SHA256,
    QUESTION_RESOLUTION_BY_SHA256,
    validate_answer_key,
    validate_identity_map,
)


ROOT_DIR = Path(__file__).resolve().parent
DEFAULT_OUTPUT_DIR = ROOT_DIR / "outputs"
PROMPT_IDS: List[PromptID] = ["PF1", "PF2", "PF3"]


def parse_args(argv=None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--stage", required=True, choices=["answer", "judge", "all"])
    parser.add_argument("--data", default="")
    parser.add_argument(
        "--prompt",
        default=None,
        choices=["PF1", "PF2", "PF3", "all"],
    )
    parser.add_argument(
        "--temperature", type=float, choices=[0.0, 0.7], default=None
    )

    parser.add_argument("--model", default="")
    parser.add_argument("--base-url", default="")
    parser.add_argument("--api-key-env", default="")

    parser.add_argument("--judge-model", default="")
    parser.add_argument("--judge-base-url", default="")
    parser.add_argument("--judge-api-key-env", default="")

    parser.add_argument("--details-file", action="append", default=[])
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--rescore-all", action="store_true")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    return parser.parse_args(argv)


def resolve_existing_file(raw_path: str, argument_name: str) -> Path:
    if not raw_path.strip():
        raise ValueError(f"Missing required argument: {argument_name}")
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        path = Path.cwd() / path
    try:
        path = path.resolve(strict=True)
    except (FileNotFoundError, OSError) as exc:
        raise ValueError(f"File does not exist for {argument_name}: {path}") from exc
    if not path.is_file():
        raise ValueError(f"Path is not a file for {argument_name}: {path}")
    return path


def resolve_output_dir(raw_path: str) -> Path:
    if not raw_path.strip():
        raise ValueError("Missing required argument: --output-dir")
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        path = Path.cwd() / path
    path = path.resolve()
    if path.exists() and not path.is_dir():
        raise ValueError(f"Output path exists but is not a directory: {path}")
    return path


def _validate_url(value: str, argument_name: str, errors: List[str]) -> str:
    normalized = value.strip().rstrip("/")
    if not normalized:
        errors.append(f"Missing required argument: {argument_name}")
        return normalized
    parsed = urlparse(normalized)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        errors.append(f"{argument_name} must be an absolute HTTP(S) URL")
    if parsed.path.rstrip("/").endswith("/chat/completions"):
        errors.append(
            f"{argument_name} must be an API Base URL, not the full "
            "/chat/completions endpoint"
        )
    return normalized


def _validate_api_group(
    *,
    model: str,
    base_url: str,
    api_key_env: str,
    model_argument: str,
    url_argument: str,
    env_argument: str,
    errors: List[str],
) -> tuple[str, str, str]:
    model = model.strip()
    api_key_env = api_key_env.strip()
    if not model:
        errors.append(f"Missing required argument: {model_argument}")
    base_url = _validate_url(base_url, url_argument, errors)
    if not api_key_env:
        errors.append(f"Missing required argument: {env_argument}")
    elif not os.getenv(api_key_env):
        errors.append(f"Missing API key environment variable: {api_key_env}")
    return model, base_url, api_key_env


def safe_model_name(model: str) -> str:
    leaf = model.split("/")[-1]
    safe_name = re.sub(r"[^A-Za-z0-9_-]+", "_", leaf).strip("_")
    if not safe_name:
        raise ValueError("Model name does not contain a filename-safe character")
    return safe_name


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest().upper()


def prompt_protocol_hashes() -> Dict[str, Any]:
    candidate_hashes = {}
    for prompt_id in PROMPT_IDS:
        system_prompt = PromptManager.candidate_system_prompt(
            "<BACKGROUND>",
            "<RESOLUTION_CRITERIA>",
            "<RETRIEVAL_DATE>",
            prompt_id,
        )
        user_prompt = PromptManager.candidate_user_prompt(
            "<QUESTION>",
            "<BACKGROUND>",
            "<RESOLUTION_CRITERIA>",
            "<RETRIEVAL_DATE>",
            prompt_id,
        )
        candidate_hashes[prompt_id] = sha256_text(
            system_prompt + "\n\n" + user_prompt
        )

    dummy_result = ForecastResult(
        id="<ID>",
        question="<QUESTION>",
        background="<BACKGROUND>",
        resolution_criteria="<RESOLUTION_CRITERIA>",
        retrieval_date="<RETRIEVAL_DATE>",
        reasoning_eval="<CANDIDATE_LLM_RESPONSE>",
        confidence_assessment="Likely",
        confidence_score=0.65,
        probability=0.65,
        resolution=1,
        resolution_answer="YES",
        brier_score=(0.65 - 1) ** 2,
        accuracy=1,
        prompt_id="PF1",
    )
    judge_material = "\n\n".join(
        [PromptManager.JUDGE_SYSTEM_PROMPT, PromptManager.judge_prompt(dummy_result)]
    )
    return {
        "candidate": candidate_hashes,
        "judge": {
            "protocol": PromptManager.JUDGE_PROTOCOL,
            "sha256": sha256_text(judge_material),
        },
    }


def selected_prompt_ids(value: Optional[str]) -> List[PromptID]:
    if value == "all":
        return list(PROMPT_IDS)
    if value in PROMPT_IDS:
        return [value]
    raise ValueError("Missing required argument: --prompt")


def answer_output_paths(
    output_dir: Path,
    model: str,
    prompt_id: PromptID,
    temperature: float,
) -> tuple[Path, Path]:
    suffix = f"{safe_model_name(model)}_{prompt_id}_temp{temperature}"
    return (
        output_dir / f"forecast_details_{suffix}.jsonl",
        output_dir / f"failed_answers_{suffix}.jsonl",
    )


def validate_runtime_inputs(args: argparse.Namespace) -> Dict[str, Any]:
    errors: List[str] = []
    if args.limit is not None and args.limit < 1:
        errors.append("--limit must be at least 1")

    resolved: Dict[str, Any] = {
        "output_dir": resolve_output_dir(args.output_dir),
        "data_path": None,
        "details_files": [],
        "prompt_ids": [],
    }

    if args.stage in {"answer", "all"}:
        if args.temperature is None:
            errors.append("Missing required argument: --temperature")
        try:
            resolved["prompt_ids"] = selected_prompt_ids(args.prompt)
        except ValueError as exc:
            errors.append(str(exc))
        try:
            resolved["data_path"] = resolve_existing_file(args.data, "--data")
        except ValueError as exc:
            errors.append(str(exc))
        args.model, args.base_url, args.api_key_env = _validate_api_group(
            model=args.model,
            base_url=args.base_url,
            api_key_env=args.api_key_env,
            model_argument="--model",
            url_argument="--base-url",
            env_argument="--api-key-env",
            errors=errors,
        )
        if args.details_file:
            errors.append("--details-file is only valid with --stage judge")

    if args.stage in {"judge", "all"}:
        (
            args.judge_model,
            args.judge_base_url,
            args.judge_api_key_env,
        ) = _validate_api_group(
            model=args.judge_model,
            base_url=args.judge_base_url,
            api_key_env=args.judge_api_key_env,
            model_argument="--judge-model",
            url_argument="--judge-base-url",
            env_argument="--judge-api-key-env",
            errors=errors,
        )

    if args.stage == "judge":
        if not args.details_file:
            errors.append("--stage judge requires at least one --details-file")
        for raw_path in args.details_file:
            try:
                resolved["details_files"].append(
                    resolve_existing_file(raw_path, "--details-file")
                )
            except ValueError as exc:
                errors.append(str(exc))
        if args.resume:
            errors.append("--resume is only valid with --stage answer or all")
    elif args.rescore_all:
        errors.append("--rescore-all is only valid with --stage judge")

    if args.stage == "answer" and (
        args.judge_model
        or args.judge_base_url
        or args.judge_api_key_env
    ):
        errors.append("Secondary API arguments are not used with --stage answer")
    if args.stage == "judge" and (
        args.model or args.base_url or args.api_key_env
    ):
        errors.append("Primary API arguments are not used with --stage judge")
    if args.stage == "judge" and (
        args.data or args.prompt is not None or args.temperature is not None
    ):
        errors.append(
            "--data, --prompt, and --temperature are not used with --stage judge"
        )
    if args.stage == "judge" and args.limit is not None:
        errors.append("--limit is not used with --stage judge")

    if errors:
        raise ValueError("; ".join(errors))

    if args.stage in {"answer", "all"}:
        safe_model_name(args.model)
        for prompt_id in resolved["prompt_ids"]:
            details_path, _ = answer_output_paths(
                resolved["output_dir"],
                args.model,
                prompt_id,
                args.temperature,
            )
            if details_path.exists() and not args.resume:
                raise ValueError(
                    f"Output already exists: {details_path}. Use --resume or "
                    "choose another --output-dir."
                )
    return resolved


def build_api_settings(
    model: str,
    base_url: str,
    api_key_env: str,
) -> APISettings:
    return APISettings(model=model, base_url=base_url, api_key_env=api_key_env)


def load_results(
    path: Path, expected_prompt: Optional[PromptID] = None
) -> List[ForecastResult]:
    answer_key_sha256 = validate_answer_key()
    identity_map_sha256 = validate_identity_map()
    results: List[ForecastResult] = []
    seen_ids = set()
    if not path.exists():
        return results
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                raw_result = json.loads(line)
                if "crowd_prediction" in raw_result:
                    raise ValueError("crowd_prediction is not allowed")
                result = ForecastResult(**raw_result)
            except Exception as exc:
                raise ValueError(
                    f"Invalid result at {path}:{line_number}: {exc}"
                ) from exc
            if expected_prompt is not None and result.prompt_id != expected_prompt:
                raise ValueError(
                    f"Unexpected template ID at {path}:{line_number}: "
                    f"{result.prompt_id}"
                )
            if result.id in seen_ids:
                raise ValueError(
                    f"Duplicate M3 ID at {path}:{line_number}: {result.id}"
                )
            question_key = DataManager.question_sha256(result.question)
            if question_key not in QUESTION_RESOLUTION_BY_SHA256:
                raise ValueError(
                    "Result record has no exact M3 reference-map match at "
                    f"{path}:{line_number}: {result.question!r}; "
                    f"answer_key_sha256={answer_key_sha256}"
                )
            expected_id = QUESTION_ID_BY_SHA256.get(question_key)
            if expected_id != result.id:
                raise ValueError(
                    "Result ID does not match the exact formal M3 record "
                    f"identity at {path}:{line_number}: id={result.id!r}, "
                    f"expected={expected_id!r}; "
                    f"identity_map_sha256={identity_map_sha256}"
                )
            expected_resolution = QUESTION_RESOLUTION_BY_SHA256[question_key]
            expected_answer = "YES" if expected_resolution == 1 else "NO"
            expected_brier = (result.probability - expected_resolution) ** 2
            expected_accuracy = int(
                (result.probability > 0.5) == (expected_resolution > 0.5)
            )
            if result.resolution != expected_resolution:
                raise ValueError(
                    f"Incorrect resolution at {path}:{line_number} for {result.id}"
                )
            if result.resolution_answer != expected_answer:
                raise ValueError(
                    "Incorrect resolution_answer at "
                    f"{path}:{line_number} for {result.id}"
                )
            if abs(result.brier_score - expected_brier) > 1e-12:
                raise ValueError(
                    f"Incorrect reference metric at {path}:{line_number} for {result.id}"
                )
            if result.accuracy != expected_accuracy:
                raise ValueError(
                    f"Incorrect accuracy at {path}:{line_number} for {result.id}"
                )
            seen_ids.add(result.id)
            results.append(result)
    return results


def write_json(path: Path, payload: Any) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)


def append_failure(path: Path, payload: Dict[str, Any]) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False) + "\n")


def write_results_atomically(
    path: Path, results: Iterable[ForecastResult]
) -> None:
    temporary_path = path.with_name(path.name + ".tmp")
    try:
        with temporary_path.open("w", encoding="utf-8") as handle:
            for result in results:
                handle.write(result.model_dump_json(exclude_none=True) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_path, path)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


def run_answer_prompt(
    *,
    items,
    source_count: int,
    prompt_id: PromptID,
    temperature: float,
    model: str,
    output_dir: Path,
    resume: bool,
    evaluator: CandidateEvaluator,
) -> Dict[str, Any]:
    details_path, failures_path = answer_output_paths(
        output_dir, model, prompt_id, temperature
    )
    results = load_results(details_path, expected_prompt=prompt_id) if resume else []
    finished_ids = {result.id for result in results}
    tasks = [item for item in items if item.id not in finished_ids]

    print(f"\n=== M3 {prompt_id}, temperature={temperature} ===")
    print(
        f"Selected: {len(items)}; completed: {len(results)}; "
        f"pending: {len(tasks)}"
    )
    if tasks:
        with details_path.open("a", encoding="utf-8") as details_handle:
            for index, item in enumerate(tasks, start=1):
                try:
                    result = evaluator.evaluate(item, prompt_id, temperature)
                except Exception as exc:
                    failure = {
                        "timestamp": datetime.now().isoformat(timespec="seconds"),
                        "prompt_id": prompt_id,
                        "id": item.id,
                        "error": str(exc),
                    }
                    raw_response = getattr(exc, "raw_response", None)
                    if raw_response is not None:
                        failure["raw_response"] = raw_response
                    append_failure(failures_path, failure)
                    print(f"[{index}/{len(tasks)}] Failed {item.id}: {exc}")
                    continue

                details_handle.write(
                    result.model_dump_json(exclude_none=True) + "\n"
                )
                details_handle.flush()
                results.append(result)
                print(
                    f"[{index}/{len(tasks)}] {item.id}: "
                    f"value={result.probability:.4f}, "
                    f"band={result.confidence_assessment}"
                )

    return {
        "prompt_id": prompt_id,
        "details_path": str(details_path),
        "source_question_count": source_count,
        "selected_question_count": len(items),
        "result_count": len(results),
        "answer_failures": max(0, len(items) - len(results)),
    }


def run_judge_file(
    *,
    details_path: Path,
    rescore_all: bool,
    judge: ReasoningJudge,
) -> Dict[str, Any]:
    results = load_results(details_path)
    if not results:
        raise ValueError(f"Details file contains no valid results: {details_path}")

    target_indices = [
        index
        for index, result in enumerate(results)
        if rescore_all or result.reasoning_score is None
    ]
    failures_path = details_path.with_name(
        f"failed_judgments_{details_path.stem}.jsonl"
    )
    failed_count = 0

    print(f"\n=== Secondary stage {details_path.name} ===")
    print(f"Rows: {len(results)}; pending: {len(target_indices)}")
    if target_indices:
        for completed, row_index in enumerate(target_indices, start=1):
            result = results[row_index]
            try:
                results[row_index] = judge.evaluate(result)
            except Exception as exc:
                failed_count += 1
                failure = {
                    "timestamp": datetime.now().isoformat(timespec="seconds"),
                    "prompt_id": result.prompt_id,
                    "id": result.id,
                    "error": str(exc),
                }
                raw_response = getattr(exc, "raw_response", None)
                if raw_response is not None:
                    failure["raw_judge_response"] = raw_response
                append_failure(failures_path, failure)
                print(
                    f"[{completed}/{len(target_indices)}] Secondary stage failed "
                    f"{result.id}: {exc}"
                )
                continue
            print(
                f"[{completed}/{len(target_indices)}] Secondary stage complete "
                f"{result.id}: score={results[row_index].reasoning_score}"
            )
        write_results_atomically(details_path, results)

    missing_scores = sum(result.reasoning_score is None for result in results)
    return {
        "details_path": str(details_path),
        "result_count": len(results),
        "reasoning_scored": len(results) - missing_scores,
        "judge_attempts": len(target_indices),
        "judge_failures": failed_count,
    }


def run_config_path(
    output_dir: Path,
    args: argparse.Namespace,
) -> Path:
    name = "run_config.json"
    if args.stage in {"answer", "all"} and args.temperature is not None:
        name = f"run_config_{safe_model_name(args.model)}_temp{args.temperature}.json"
    return output_dir / name


def current_input_contract(data_path: Optional[Path]) -> Dict[str, Any]:
    answer_key_sha256 = validate_answer_key()
    identity_map_sha256 = validate_identity_map()
    return {
        "input_contract_version": INPUT_CONTRACT_VERSION,
        "dataset_sha256": sha256_file(data_path) if data_path else None,
        "answer_key_sha256": answer_key_sha256,
        "identity_map_sha256": identity_map_sha256,
        "answer_count": ANSWER_COUNT,
    }


def validate_resume_contract(
    output_dir: Path,
    args: argparse.Namespace,
    data_path: Path,
) -> None:
    path = run_config_path(output_dir, args)
    if not path.is_file():
        raise ValueError(
            f"Cannot resume without the matching run configuration: {path}"
        )
    try:
        stored = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Cannot read resume configuration {path}: {exc}") from exc
    expected = current_input_contract(data_path)
    for field, expected_value in expected.items():
        if field not in stored:
            raise ValueError(
                f"Run configuration cannot be resumed; missing {field}: {path}"
            )
        if stored[field] != expected_value:
            raise ValueError(
                f"Resume input contract mismatch for {field}: "
                f"stored={stored[field]!r}, current={expected_value!r}"
            )


def write_run_config(
    output_dir: Path,
    args: argparse.Namespace,
    prompt_ids: List[PromptID],
    data_path: Optional[Path],
    details_files: List[Path],
) -> None:
    payload = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "stage": args.stage,
        "data_path": str(data_path) if data_path else None,
        **current_input_contract(data_path),
        "details_inputs": [
            {"path": str(path), "sha256": sha256_file(path)}
            for path in details_files
        ],
        "prompt_ids": prompt_ids,
        "prompt_protocol_sha256": prompt_protocol_hashes(),
        "temperature": args.temperature,
        "model": args.model or None,
        "base_url": args.base_url or None,
        "api_key_env": args.api_key_env or None,
        "judge_model": args.judge_model or None,
        "judge_base_url": args.judge_base_url or None,
        "judge_api_key_env": args.judge_api_key_env or None,
        "judge_protocol": (
            PromptManager.JUDGE_PROTOCOL
            if args.stage in {"judge", "all"}
            else None
        ),
        "judge_temperature": 0.0 if args.stage in {"judge", "all"} else None,
        "limit": args.limit,
        "resume": args.resume,
        "rescore_all": args.rescore_all,
        "output_dir": str(output_dir),
    }
    write_json(run_config_path(output_dir, args), payload)


def main(
    argv=None,
    *,
    candidate_client: Optional[Any] = None,
    judge_client: Optional[Any] = None,
) -> int:
    args = parse_args(argv)
    try:
        resolved = validate_runtime_inputs(args)
    except ValueError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2

    output_dir: Path = resolved["output_dir"]
    try:

        current_input_contract(resolved["data_path"])
    except RuntimeError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2
    if args.resume:
        try:
            validate_resume_contract(
                output_dir, args, resolved["data_path"]
            )
        except (ValueError, RuntimeError) as exc:
            print(f"Configuration error: {exc}", file=sys.stderr)
            return 2
    output_dir.mkdir(parents=True, exist_ok=True)
    try:
        write_run_config(
            output_dir,
            args,
            resolved["prompt_ids"],
            resolved["data_path"],
            resolved["details_files"],
        )
    except RuntimeError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2

    answer_summaries = []
    judge_summaries = []
    try:
        if args.stage in {"answer", "all"}:
            data = DataManager.load_data(resolved["data_path"])
            selected_items = data[: args.limit] if args.limit else data
            if candidate_client is None:
                candidate_client = LLMClient(
                    build_api_settings(args.model, args.base_url, args.api_key_env)
                )
            evaluator = CandidateEvaluator(candidate_client)
            for prompt_id in resolved["prompt_ids"]:
                answer_summaries.append(
                    run_answer_prompt(
                        items=selected_items,
                        source_count=len(data),
                        prompt_id=prompt_id,
                        temperature=args.temperature,
                        model=args.model,
                        output_dir=output_dir,
                        resume=args.resume,
                        evaluator=evaluator,
                    )
                )

        if args.stage in {"judge", "all"}:
            if judge_client is None:
                judge_client = LLMClient(
                    build_api_settings(
                        args.judge_model,
                        args.judge_base_url,
                        args.judge_api_key_env,
                    )
                )
            judge = ReasoningJudge(judge_client)
            details_files = (
                [Path(summary["details_path"]) for summary in answer_summaries]
                if args.stage == "all"
                else resolved["details_files"]
            )
            for details_path in details_files:
                judge_summaries.append(
                    run_judge_file(
                        details_path=details_path,
                        rescore_all=args.rescore_all,
                        judge=judge,
                    )
                )
    except Exception as exc:
        print(f"Run failed: {exc}", file=sys.stderr)
        return 1

    summary = {
        "stage": args.stage,
        "answers": answer_summaries,
        "judgments": judge_summaries,
    }
    summary_path = output_dir / "task3_reproduction_summary.json"
    write_json(summary_path, summary)
    print(f"\nSummary: {summary_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
