import json
import re
from typing import Any, Dict, Optional, Tuple

from llm_client import LLMClient
from prompts import PromptManager
from schemas import (
    ConfidenceCategory,
    ForecastItem,
    ForecastResult,
    JudgeParseFormat,
    PromptID,
)


PROBABILITY_PATTERN = re.compile(
    r"(?im)^[ \t>*#-]*(?:\*{1,2})?(?:Final\s+)?Probability"
    r"(?:\s+(?:Score|Estimate|Prediction))?(?:\s*\([^)]*\))?"
    r"\s*(?:\*{1,2})?\s*[:=]\s*(?:(?:\*{1,2})\s*){0,2}"
    r"(?P<value>(?:\d+(?:\.\d*)?|\.\d+))\s*(?P<percent>%?)"
)

CONFIDENCE_COMMAND_PATTERN = re.compile(
    r"\\confidence\{([^{}]+)\}", re.IGNORECASE
)
CONFIDENCE_LABEL_PATTERN = re.compile(
    r"(?im)^[ \t>*#-]*(?:\*{1,2})?Confidence\s+Assessment"
    r"(?:\*{1,2})?\s*[:=]\s*(.+?)\s*$"
)
PROMETHEUS_RESULT_PATTERN = re.compile(
    r"\[RESULT\]\s*(?:Score\s*[:\-]?\s*)?([1-5])(?!\d)",
    re.IGNORECASE,
)

CONFIDENCE_SCORES: Dict[str, Tuple[ConfidenceCategory, float]] = {
    "almost no chance": ("Almost no chance", 0.05),
    "highly unlikely": ("Highly unlikely", 0.15),
    "chances are slight": ("Chances are slight", 0.25),
    "unlikely": ("Unlikely", 0.35),
    "less than even": ("Less than even", 0.45),
    "better than even": ("Better than even", 0.55),
    "likely": ("Likely", 0.65),
    "very good chance": ("Very good chance", 0.75),
    "highly likely": ("Highly likely", 0.85),
    "almost certain": ("Almost certain", 0.95),
}


class JudgeResponseParseError(ValueError):
    def __init__(self, message: str, raw_response: str):
        super().__init__(message)
        self.raw_response = raw_response


class CandidateResponseParseError(ValueError):
    def __init__(self, message: str, raw_response: str):
        super().__init__(message)
        self.raw_response = raw_response


def parse_probability(raw_response: str) -> float:
    if not raw_response or not raw_response.strip():
        raise ValueError("Candidate model returned an empty response")
    matches = list(PROBABILITY_PATTERN.finditer(raw_response))
    if not matches:
        preview = raw_response[:200].replace("\n", " ")
        raise ValueError(
            "Could not parse the required numeric output: " + preview
        )

    match = matches[-1]
    value = float(match.group("value"))
    if match.group("percent"):
        value /= 100.0
    if not 0.0 <= value <= 1.0:
        raise ValueError(f"Output value must be between 0 and 1: {value}")
    return value


def _normalize_confidence(value: str) -> Tuple[ConfidenceCategory, float]:
    cleaned = value.strip()
    command_match = CONFIDENCE_COMMAND_PATTERN.search(cleaned)
    if command_match:
        cleaned = command_match.group(1)
    cleaned = re.sub(r"[*_`]+", "", cleaned).strip()
    cleaned = cleaned.rstrip(". ;,").strip().lower()
    if cleaned not in CONFIDENCE_SCORES:
        raise ValueError(
            "Confidence Assessment must be one of the ten prescribed categories: "
            f"{value!r}"
        )
    return CONFIDENCE_SCORES[cleaned]


def parse_confidence(
    raw_response: str,
) -> Tuple[ConfidenceCategory, float]:
    if not raw_response or not raw_response.strip():
        raise ValueError("Candidate model returned an empty response")

    command_matches = CONFIDENCE_COMMAND_PATTERN.findall(raw_response)
    if command_matches:
        return _normalize_confidence(command_matches[-1])

    label_matches = CONFIDENCE_LABEL_PATTERN.findall(raw_response)
    if label_matches:
        return _normalize_confidence(label_matches[-1])
    raise ValueError("Could not parse a labeled Confidence Assessment")


def _extract_json_object(text: str) -> Dict[str, Any]:
    stripped = text.strip()
    if stripped.startswith("```"):
        stripped = re.sub(r"^```(?:json)?\s*", "", stripped, flags=re.I)
        stripped = re.sub(r"\s*```$", "", stripped)

    candidates = [stripped]
    start = stripped.find("{")
    end = stripped.rfind("}")
    if start != -1 and end > start:
        candidates.append(stripped[start : end + 1])
    for candidate in candidates:
        try:
            value = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            return value
    raise ValueError("Secondary response does not contain a valid JSON object")


def _normalize_judge_payload(payload: Dict[str, Any]) -> Tuple[int, str]:
    normalized = {str(key).lower(): value for key, value in payload.items()}
    score = normalized.get("score")
    feedback = normalized.get("feedback")
    if isinstance(score, bool):
        raise ValueError("Secondary score cannot be a boolean")
    if isinstance(score, str) and score.strip().isdigit():
        score = int(score.strip())
    if not isinstance(score, int) or score not in {1, 2, 3, 4, 5}:
        raise ValueError(f"Secondary score must be an integer from 1 to 5: {score!r}")
    if not isinstance(feedback, str) or not feedback.strip():
        raise ValueError("Secondary message must be a non-empty string")
    return score, feedback.strip()


def parse_judge_response_with_format(
    raw_response: str,
) -> Tuple[int, str, JudgeParseFormat]:
    if not raw_response or not raw_response.strip():
        raise JudgeResponseParseError(
            "Secondary stage returned an empty response", raw_response or ""
        )

    json_error: Optional[Exception] = None
    try:
        return (*_normalize_judge_payload(_extract_json_object(raw_response)), "json")
    except ValueError as exc:
        json_error = exc

    matches = list(PROMETHEUS_RESULT_PATTERN.finditer(raw_response))
    if matches:
        match = matches[-1]
        feedback = raw_response[: match.start()].strip()
        feedback = re.sub(
            r"^\s*Feedback\s*:\s*", "", feedback, flags=re.IGNORECASE
        ).strip()
        if feedback:
            return int(match.group(1)), feedback, "prometheus_result"

    preview = raw_response[:200].replace("\n", " ")
    raise JudgeResponseParseError(
        "Secondary response is neither valid Appendix S3 JSON nor a valid "
        f"Prometheus [RESULT] response: {preview}. JSON error: {json_error}",
        raw_response,
    )


def parse_judge_response(raw_response: str) -> Tuple[int, str]:
    score, feedback, _ = parse_judge_response_with_format(raw_response)
    return score, feedback


class CandidateEvaluator:
    def __init__(self, client: LLMClient):
        self.client = client

    def evaluate(
        self,
        item: ForecastItem,
        prompt_id: PromptID,
        temperature: float,
    ) -> ForecastResult:
        raw_response = self.client.call_model(
            PromptManager.candidate_messages(item, prompt_id),
            temperature=temperature,
            max_tokens=4096,
        )
        try:
            probability = parse_probability(raw_response)
            confidence_assessment, confidence_score = parse_confidence(raw_response)
        except ValueError as exc:
            raise CandidateResponseParseError(str(exc), raw_response) from exc
        brier_score = (probability - item.resolution) ** 2
        accuracy = int((probability > 0.5) == (item.resolution > 0.5))
        return ForecastResult(
            id=item.id,
            question=item.question,
            background=item.background,
            resolution_criteria=item.resolution_criteria,
            retrieval_date=item.retrieval_date,
            reasoning_eval=raw_response,
            confidence_assessment=confidence_assessment,
            confidence_score=confidence_score,
            probability=probability,
            resolution=item.resolution,
            resolution_answer=item.resolution_answer,
            brier_score=brier_score,
            accuracy=accuracy,
            prompt_id=prompt_id,
        )


class ReasoningJudge:
    def __init__(self, client: LLMClient):
        self.client = client

    def evaluate(self, result: ForecastResult) -> ForecastResult:
        raw_response = self.client.call_model(
            [
                {
                    "role": "system",
                    "content": PromptManager.JUDGE_SYSTEM_PROMPT,
                },
                {
                    "role": "user",
                    "content": PromptManager.judge_prompt(result),
                },
            ],
            temperature=0.0,
            max_tokens=2048,
        )
        score, feedback, parse_format = parse_judge_response_with_format(
            raw_response
        )
        return result.model_copy(
            update={
                "reasoning_score": score,
                "reasoning_feedback": feedback,
                "raw_judge_response": raw_response,
                "judge_parse_format": parse_format,
                "judge_protocol": PromptManager.JUDGE_PROTOCOL,
            }
        )
