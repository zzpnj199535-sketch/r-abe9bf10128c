from schemas import PromptID


class PromptManager:
    JUDGE_PROTOCOL = "appendix_s2_json"

    NASA_DEFINITIONS = "NASA TRL"

    PA1_TEMPLATE = """### SYSTEM ROLE
You are a **Strict Technology Manager** responsible for the rigorous assessment of technology portfolios. Your primary goal is to determine the accurate Technology Readiness Level (TRL) of a project to ensure no premature advancement risks are taken.

### OBJECTIVE
Evaluate the provided Technical Description exclusively based on the Official NASA TRL Definitions below. You must act as a gatekeeper: do not award a TRL level unless all criteria for that level (and previous levels) are explicitly met in the text.

{definitions}

### TASK INSTRUCTIONS
1. Read the Technical Description.
2. Match the description against the terminology and definitions.
3. Determine the highest verified TRL.
4. Provide a concise analysis of the evidence.
5. Output the reasoning followed by the final TRL level in the specified format.

### FORMAT CONSTRAINT
Output your final answer in this exact format:
**Reasoning:** [Provide a concise analysis of the evidence]
**Final Answer: TRL [Number]**

### TECHNICAL DESCRIPTION
{description}"""

    PA2_TEMPLATE = """### SYSTEM ROLE
You are a **Strict Technology Manager** responsible for the rigorous assessment of technology portfolios. Your primary goal is to determine the accurate Technology Readiness Level (TRL) of a project to ensure no premature advancement risks are taken.

### OBJECTIVE
Evaluate the provided Technical Description exclusively based on the Official NASA TRL Definitions below. You must act as a gatekeeper: do not award a TRL level unless all criteria for that level (and previous levels) are explicitly met in the text.

{definitions}

### EXAMPLES

<Example 1>
**Technical Description:**
"A breadboard Er:YAG laser transmitter was built for direct generation of a 1.65 µm wavelength. This low-fidelity component was tested in a laboratory environment, where it demonstrated an output of greater than 500 µJ per pulse at a 10 kHz pulse repetition rate and a tunable operating wavelength at a methane absorption line. The technical performance results from these breadboard experiments established that the laser approach could meet NASA's methane lidar requirements."
**Final Answer: TRL 4**
</Example 1>

<Example 2>
**Technical Description:**
"A dual-element PPKTP waveguide module was designed, fabricated, and packaged. This brassboard component was delivered and integrated with a partner's space-to-ground entanglement distribution test bed. In this relevant test environment, the module demonstrated a polarization entanglement fidelity of 0.95."
**Final Answer: TRL 5**
</Example 2>

<Example 3>
**Technical Description:**
"A prototype thermal corer, an improved PVEx drill with integrated minichannels, was developed. It was characterized through in-house performance testing and was successfully demonstrated in a simulated lunar environment inside a thermal vacuum chamber. The testing in relevant conditions showed an ice recovery rate greater than 60% with the regolith environment maintained at -30°C and 1E-3 Torr."
**Final Answer: TRL 6**
</Example 3>

### TASK INSTRUCTIONS
1. Read the Technical Description below.
2. Refer to the Examples above to understand the mapping between description features and TRL levels.
3. Determine the highest verified TRL based on the Definitions and Assessment Rules.
4. Provide a concise analysis of the evidence.
5. Output the reasoning followed by the final TRL level in the specified format.

### FORMAT CONSTRAINT
Output your final answer in this exact format:
**Reasoning:** [Provide a concise analysis of the evidence]
**Final Answer: TRL [Number]**

### TECHNICAL DESCRIPTION
{description}"""

    PA3_TEMPLATE = """### SYSTEM ROLE
You are a **Strict Technology Manager** responsible for the rigorous assessment of technology portfolios. Your primary goal is to determine the accurate Technology Readiness Level (TRL) of a project to ensure no premature advancement risks are taken.

### OBJECTIVE
Evaluate the provided Technical Description exclusively based on the Official NASA TRL Definitions below. You must act as a gatekeeper: do not award a TRL level unless all criteria for that level (and previous levels) are explicitly met in the text.

{definitions}

### EXAMPLES

<Example 1>
**Technical Description:**
"A breadboard Er:YAG laser transmitter was built for direct generation of a 1.65 µm wavelength. This low-fidelity component was tested in a laboratory environment, where it demonstrated an output of greater than 500 µJ per pulse at a 10 kHz pulse repetition rate and a tunable operating wavelength at a methane absorption line. The technical performance results from these breadboard experiments established that the laser approach could meet NASA's methane lidar requirements."
**Reasoning:** The hardware is explicitly identified as a low-fidelity "breadboard" tested in a benign "laboratory environment", which aligns perfectly with TRL 4 criteria.
**Final Answer: TRL 4**
</Example 1>

<Example 2>
**Technical Description:**
"A dual-element PPKTP waveguide module was designed, fabricated, and packaged. This brassboard component was delivered and integrated with a partner's space-to-ground entanglement distribution test bed. In this relevant test environment, the module demonstrated a polarization entanglement fidelity of 0.95."
**Reasoning:** Although tested in a lab facility, the "brassboard" fidelity and use of "vacuum" and "simulants" (implied by "relevant test environment") constitute a Relevant Environment, meeting the requirements for TRL 5.
**Final Answer: TRL 5**
</Example 2>

<Example 3>
**Technical Description:**
"A prototype thermal corer, an improved PVEx drill with integrated minichannels, was developed. It was characterized through in-house performance testing and was successfully demonstrated in a simulated lunar environment inside a thermal vacuum chamber. The testing in relevant conditions showed an ice recovery rate greater than 60% with the regolith environment maintained at -30°C and 1E-3 Torr."
**Reasoning:** The high-fidelity "prototype" system demonstrated in a "simulated lunar environment" (Relevant Environment) satisfies the definition of TRL 6.
**Final Answer: TRL 6**
</Example 3>

### TASK INSTRUCTIONS
1. Read the Technical Description below.
2. Refer to the Examples above to understand the mapping between description features and TRL levels.
3. Determine the highest verified TRL based on the Definitions and Assessment Rules.
4. Provide a **single sentence** of reasoning explaining why it matches a specific TRL.
5. Output the reasoning followed by the final TRL level in the specified format.

### FORMAT CONSTRAINT
Output your final answer in this exact format:
**Reasoning:** [Provide a concise analysis of the evidence]
**Final Answer: TRL [Number]**

### TECHNICAL DESCRIPTION
{description}"""

    JUDGE_SYSTEM_PROMPT = (
        "You are an objective and highly analytical judge assistant. Your core "
        "philosophy is to evaluate logic strictly, fairly, and without score inflation."
    )

    JUDGE_RUBRIC = """1: The final conclusion fundamentally contradicts the ground truth. The derivation process is illogical or entirely absent. The model fails to identify any key technical evidence and demonstrates zero coverage of the necessary TRL criteria.
2: The conclusion is vague or deviates from the ground truth. The logical soundness of the derivation is weak. The model mentions technical concepts but fails in the effective identification of specific key technical evidence. Completeness of coverage regarding necessary TRL criteria is highly inadequate.
3: The conclusion is mostly correct relative to the ground truth, but the derivation process contains logical gaps or lacks rigorous deduction. The model identifies some technical evidence but misses certain critical elements. Coverage regarding the necessary TRL criteria is only partial or incomplete.
4: The final conclusion is correct relative to the ground truth. The derivation process is logically sound. The model demonstrates effective identification of key technical evidence and provides complete coverage regarding the necessary TRL criteria to support the assessment.
5: The final conclusion perfectly matches the ground truth. The derivation process is flawlessly logical and highly rigorous. The model exhibits exceptional and granular identification of key technical evidence, demonstrating exhaustive completeness of coverage regarding all necessary TRL criteria."""

    JUDGE_TEMPLATE = """### TASK
Use the provided Rubric and NASA definitions to evaluate the reasoning quality of the Candidate LLM Response against the provided Technical Description and TRL. Return a JSON object with two fields: "Score" (integer 1-5) and "Feedback" (an evidence-backed justification).

{definitions}

### INPUT
**Technical Description:**
{description}

**TRL:** {target_trl}

**Candidate LLM Response:**
{candidate_response}

### RUBRIC
{rubric}

### OUTPUT FORMAT
Return only a valid JSON object in this form:
{{"Score": 4, "Feedback": "Evidence-backed justification."}}"""

    TEMPLATES = {
        "PA1": PA1_TEMPLATE,
        "PA2": PA2_TEMPLATE,
        "PA3": PA3_TEMPLATE,
    }

    @classmethod
    def candidate_prompt(cls, description: str, prompt_id: PromptID) -> str:
        try:
            template = cls.TEMPLATES[prompt_id]
        except KeyError as exc:
            raise ValueError(f"Unsupported prompt ID: {prompt_id}") from exc
        return template.format(
            definitions=cls.NASA_DEFINITIONS,
            description=description,
        )

    @classmethod
    def judge_prompt(
        cls,
        description: str,
        target_trl: int,
        candidate_response: str,
    ) -> str:
        return cls.JUDGE_TEMPLATE.format(
            definitions=cls.NASA_DEFINITIONS,
            description=description,
            target_trl=target_trl,
            candidate_response=candidate_response,
            rubric=cls.JUDGE_RUBRIC,
        )
