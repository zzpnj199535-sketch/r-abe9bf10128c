import json
import re
from typing import Any, Dict, Optional, Tuple

from llm_client import LLMClient
from prompts import PromptManager
from schemas import JudgeParseFormat, PromptID, TRLData, TRLResult


FINAL_ANSWER_PATTERN = re.compile(
    r"(?:\*\*)?Final\s+Answer\s*:\s*TRL\s*([1-9])(?!\d)(?:\*\*)?",
    re.IGNORECASE,
)

FALLBACK_PATTERNS = (
    re.compile(r"Technology\s+Readiness\s+Level\s*[:\-]?\s*([1-9])(?!\d)", re.I),
    re.compile(r"TRL\s+Level\s*[:\-]?\s*([1-9])(?!\d)", re.I),
    re.compile(r"TRL\s*[:\-]?\s*([1-9])(?!\d)", re.I),
)

PROMETHEUS_RESULT_PATTERN = re.compile(
    r"\[RESULT\]\s*(?:Score\s*[:\-]?\s*)?([1-5])(?!\d)",
    re.IGNORECASE,
)


class JudgeResponseParseError(ValueError):
    def __init__(self, message: str, raw_response: str):
        super().__init__(message)
        self.raw_response = raw_response


def parse_trl_response(raw_response: str) -> int:
    if not raw_response or not raw_response.strip():
        raise ValueError("Candidate model returned an empty response")

    final_matches = FINAL_ANSWER_PATTERN.findall(raw_response)
    if final_matches:
        return int(final_matches[-1])

    for pattern in FALLBACK_PATTERNS:
        matches = pattern.findall(raw_response)
        if matches:
            return int(matches[-1])
    preview = raw_response[:200].replace("\n", " ")
    raise ValueError(f"Could not parse the required value: {preview}")


def _extract_json_object(text: str) -> Dict[str, Any]:
    stripped = text.strip()
    if stripped.startswith("```"):
        stripped = re.sub(r"^```(?:json)?\s*", "", stripped, flags=re.I)
        stripped = re.sub(r"\s*```$", "", stripped)

    candidates = [stripped]
    start = stripped.find("{")
    end = stripped.rfind("}")
    if start != -1 and end > start:
        candidates.append(stripped[start : end + 1])

    for candidate in candidates:
        try:
            value = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            return value
    raise ValueError("Secondary response does not contain a valid JSON object")


def _normalize_judge_payload(payload: Dict[str, Any]) -> Tuple[int, str]:
    normalized = {str(key).lower(): value for key, value in payload.items()}
    score = normalized.get("score")
    feedback = normalized.get("feedback")

    if isinstance(score, bool):
        raise ValueError("Secondary score cannot be a boolean")
    if isinstance(score, str) and score.strip().isdigit():
        score = int(score.strip())
    if not isinstance(score, int) or score not in {1, 2, 3, 4, 5}:
        raise ValueError(f"Secondary score must be an integer from 1 to 5: {score!r}")
    if not isinstance(feedback, str) or not feedback.strip():
        raise ValueError("Secondary message must be a non-empty string")
    return score, feedback.strip()


def parse_judge_response_with_format(
    raw_response: str,
) -> Tuple[int, str, JudgeParseFormat]:
    if not raw_response or not raw_response.strip():
        raise JudgeResponseParseError(
            "Secondary stage returned an empty response", raw_response or ""
        )

    json_error: Optional[Exception] = None
    try:
        return (*_normalize_judge_payload(_extract_json_object(raw_response)), "json")
    except ValueError as exc:
        json_error = exc

    matches = list(PROMETHEUS_RESULT_PATTERN.finditer(raw_response))
    if matches:
        match = matches[-1]
        feedback = raw_response[: match.start()].strip()
        feedback = re.sub(
            r"^\s*Feedback\s*:\s*", "", feedback, flags=re.IGNORECASE
        ).strip()
        if feedback:
            return int(match.group(1)), feedback, "prometheus_result"

    preview = raw_response[:200].replace("\n", " ")
    raise JudgeResponseParseError(
        "Secondary response is neither valid Appendix S2 JSON nor a valid "
        f"Prometheus [RESULT] response: {preview}. JSON error: {json_error}",
        raw_response,
    )


def parse_judge_response(raw_response: str) -> Tuple[int, str]:
    score, feedback, _ = parse_judge_response_with_format(raw_response)
    return score, feedback


class CandidateEvaluator:
    def __init__(self, client: LLMClient):
        self.client = client

    def evaluate(
        self,
        item: TRLData,
        prompt_id: PromptID,
        temperature: float,
    ) -> TRLResult:
        prompt = PromptManager.candidate_prompt(
            item.technology_description,
            prompt_id,
        )
        raw_response = self.client.call_model(
            [{"role": "user", "content": prompt}],
            temperature=temperature,
            max_tokens=2048,
        )
        predicted_trl = parse_trl_response(raw_response)
        return TRLResult(
            technology_description=item.technology_description,
            reasoning_eval=raw_response,
            metrics=predicted_trl,
            project_id=item.project_id,
            ground_truth_trl=item.target_trl,
            prompt_id=prompt_id,
            reasoning_score=None,
            reasoning_feedback=None,
        )


class ReasoningJudge:
    def __init__(self, client: LLMClient):
        self.client = client

    def evaluate(self, result: TRLResult) -> TRLResult:
        judge_prompt = PromptManager.judge_prompt(
            result.technology_description,
            result.ground_truth_trl,
            result.reasoning_eval,
        )
        raw_response = self.client.call_model(
            [
                {
                    "role": "system",
                    "content": PromptManager.JUDGE_SYSTEM_PROMPT,
                },
                {"role": "user", "content": judge_prompt},
            ],
            temperature=0.0,
            max_tokens=1024,
        )
        score, feedback, parse_format = parse_judge_response_with_format(
            raw_response
        )
        return result.model_copy(
            update={
                "reasoning_score": score,
                "reasoning_feedback": feedback,
                "raw_judge_response": raw_response,
                "judge_parse_format": parse_format,
                "judge_protocol": PromptManager.JUDGE_PROTOCOL,
            }
        )
