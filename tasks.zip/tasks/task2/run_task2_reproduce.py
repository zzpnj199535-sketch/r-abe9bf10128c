import argparse
import hashlib
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional
from urllib.parse import urlparse

from config import APISettings
from data_manager import DataManager
from evaluator import CandidateEvaluator, ReasoningJudge
from llm_client import LLMClient
from prompts import PromptManager
from schemas import PromptID, TRLResult
from task2_answer_key import (
    ANSWER_KEY_SHA256,
    EXPECTED_ANSWER_COUNT,
    INPUT_CONTRACT_VERSION,
    TARGET_TRL_BY_PROJECT_ID,
    validate_answer_key,
)


ROOT_DIR = Path(__file__).resolve().parent
DEFAULT_OUTPUT_DIR = ROOT_DIR / "outputs"
PROMPT_IDS: List[PromptID] = ["PA1", "PA2", "PA3"]


def parse_args(argv=None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--stage", required=True, choices=["answer", "judge", "all"])
    parser.add_argument("--data", default="")
    parser.add_argument(
        "--prompt",
        default=None,
        choices=["PA1", "PA2", "PA3", "all"],
    )
    parser.add_argument(
        "--temperature", type=float, choices=[0.0, 0.7], default=None
    )

    parser.add_argument("--model", default="")
    parser.add_argument("--base-url", default="")
    parser.add_argument("--api-key-env", default="")

    parser.add_argument("--judge-model", default="")
    parser.add_argument("--judge-base-url", default="")
    parser.add_argument("--judge-api-key-env", default="")

    parser.add_argument("--details-file", action="append", default=[])
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--rescore-all", action="store_true")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    return parser.parse_args(argv)


def resolve_existing_file(raw_path: str, argument_name: str) -> Path:
    if not raw_path.strip():
        raise ValueError(f"Missing required argument: {argument_name}")
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        path = Path.cwd() / path
    try:
        path = path.resolve(strict=True)
    except (FileNotFoundError, OSError) as exc:
        raise ValueError(f"File does not exist for {argument_name}: {path}") from exc
    if not path.is_file():
        raise ValueError(f"Path is not a file for {argument_name}: {path}")
    return path


def resolve_output_dir(raw_path: str) -> Path:
    if not raw_path.strip():
        raise ValueError("Missing required argument: --output-dir")
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        path = Path.cwd() / path
    path = path.resolve()
    if path.exists() and not path.is_dir():
        raise ValueError(f"Output path exists but is not a directory: {path}")
    return path


def _validate_url(value: str, argument_name: str, errors: List[str]) -> str:
    normalized = value.strip().rstrip("/")
    if not normalized:
        errors.append(f"Missing required argument: {argument_name}")
        return normalized
    parsed = urlparse(normalized)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        errors.append(f"{argument_name} must be an absolute HTTP(S) URL")
    if parsed.path.rstrip("/").endswith("/chat/completions"):
        errors.append(
            f"{argument_name} must be an API Base URL, not the full "
            "/chat/completions endpoint"
        )
    return normalized


def _validate_api_group(
    *,
    model: str,
    base_url: str,
    api_key_env: str,
    model_argument: str,
    url_argument: str,
    env_argument: str,
    errors: List[str],
) -> tuple[str, str, str]:
    model = model.strip()
    api_key_env = api_key_env.strip()
    if not model:
        errors.append(f"Missing required argument: {model_argument}")
    base_url = _validate_url(base_url, url_argument, errors)
    if not api_key_env:
        errors.append(f"Missing required argument: {env_argument}")
    elif not os.getenv(api_key_env):
        errors.append(f"Missing API key environment variable: {api_key_env}")
    return model, base_url, api_key_env


def safe_model_name(model: str) -> str:
    leaf = model.split("/")[-1]
    safe_name = re.sub(r"[^A-Za-z0-9_-]+", "_", leaf).strip("_")
    if not safe_name:
        raise ValueError("Model name does not contain a filename-safe character")
    return safe_name


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest().upper()


def build_input_contract(data_path: Optional[Path]) -> Dict[str, Any]:
    validate_answer_key()
    contract: Dict[str, Any] = {
        "input_contract_version": INPUT_CONTRACT_VERSION,
        "dataset_sha256": sha256_file(data_path) if data_path else None,
        "answer_key_sha256": ANSWER_KEY_SHA256,
        "answer_count": EXPECTED_ANSWER_COUNT,
    }
    if data_path is None:
        contract["joint_input_sha256"] = None
    else:
        contract["joint_input_sha256"] = sha256_text(
            json.dumps(
                contract,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            )
        )
    return contract


def prompt_protocol_hashes() -> Dict[str, Any]:
    candidate_hashes = {
        prompt_id: sha256_text(
            PromptManager.candidate_prompt(
                "<TECHNOLOGY_DESCRIPTION>", prompt_id
            )
        )
        for prompt_id in PROMPT_IDS
    }
    judge_material = "\n\n".join(
        [
            PromptManager.JUDGE_SYSTEM_PROMPT,
            PromptManager.judge_prompt(
                "<TECHNOLOGY_DESCRIPTION>",
                4,
                "<CANDIDATE_LLM_RESPONSE>",
            ),
        ]
    )
    return {
        "candidate": candidate_hashes,
        "judge": {
            "protocol": PromptManager.JUDGE_PROTOCOL,
            "sha256": sha256_text(judge_material),
        },
    }


def selected_prompt_ids(value: Optional[str]) -> List[PromptID]:
    if value == "all":
        return list(PROMPT_IDS)
    if value in PROMPT_IDS:
        return [value]
    raise ValueError("Missing required argument: --prompt")


def answer_output_paths(
    output_dir: Path,
    model: str,
    prompt_id: PromptID,
    temperature: float,
) -> tuple[Path, Path]:
    suffix = f"{safe_model_name(model)}_{prompt_id}_temp{temperature}"
    return (
        output_dir / f"trl_details_{suffix}.jsonl",
        output_dir / f"failed_answers_{suffix}.jsonl",
    )


def validate_runtime_inputs(args: argparse.Namespace) -> Dict[str, Any]:
    errors: List[str] = []
    if args.limit is not None and args.limit < 1:
        errors.append("--limit must be at least 1")

    resolved: Dict[str, Any] = {
        "output_dir": resolve_output_dir(args.output_dir),
        "data_path": None,
        "details_files": [],
        "prompt_ids": [],
    }

    if args.stage in {"answer", "all"}:
        if args.temperature is None:
            errors.append("Missing required argument: --temperature")
        try:
            resolved["prompt_ids"] = selected_prompt_ids(args.prompt)
        except ValueError as exc:
            errors.append(str(exc))
        try:
            resolved["data_path"] = resolve_existing_file(args.data, "--data")
        except ValueError as exc:
            errors.append(str(exc))
        args.model, args.base_url, args.api_key_env = _validate_api_group(
            model=args.model,
            base_url=args.base_url,
            api_key_env=args.api_key_env,
            model_argument="--model",
            url_argument="--base-url",
            env_argument="--api-key-env",
            errors=errors,
        )
        if args.details_file:
            errors.append("--details-file is only valid with --stage judge")

    if args.stage in {"judge", "all"}:
        (
            args.judge_model,
            args.judge_base_url,
            args.judge_api_key_env,
        ) = _validate_api_group(
            model=args.judge_model,
            base_url=args.judge_base_url,
            api_key_env=args.judge_api_key_env,
            model_argument="--judge-model",
            url_argument="--judge-base-url",
            env_argument="--judge-api-key-env",
            errors=errors,
        )

    if args.stage == "judge":
        if not args.details_file:
            errors.append("--stage judge requires at least one --details-file")
        for raw_path in args.details_file:
            try:
                resolved["details_files"].append(
                    resolve_existing_file(raw_path, "--details-file")
                )
            except ValueError as exc:
                errors.append(str(exc))
        if args.resume:
            errors.append("--resume is only valid with --stage answer or all")
    elif args.rescore_all:
        errors.append("--rescore-all is only valid with --stage judge")

    if args.stage == "answer" and (
        args.judge_model
        or args.judge_base_url
        or args.judge_api_key_env
    ):
        errors.append("Secondary API arguments are not used with --stage answer")

    if args.stage == "judge" and (
        args.model or args.base_url or args.api_key_env
    ):
        errors.append("Primary API arguments are not used with --stage judge")
    if args.stage == "judge" and (
        args.data or args.prompt is not None or args.temperature is not None
    ):
        errors.append(
            "--data, --prompt, and --temperature are not used with --stage judge"
        )
    if args.stage == "judge" and args.limit is not None:
        errors.append("--limit is not used with --stage judge")

    if errors:
        raise ValueError("; ".join(errors))

    if args.stage in {"answer", "all"}:
        safe_model_name(args.model)
        for prompt_id in resolved["prompt_ids"]:
            details_path, _ = answer_output_paths(
                resolved["output_dir"],
                args.model,
                prompt_id,
                args.temperature,
            )
            if details_path.exists() and not args.resume:
                raise ValueError(
                    f"Output already exists: {details_path}. Use --resume or "
                    "choose another --output-dir."
                )
    return resolved


def build_api_settings(
    model: str,
    base_url: str,
    api_key_env: str,
) -> APISettings:
    return APISettings(
        model=model,
        base_url=base_url,
        api_key_env=api_key_env,
    )


def load_results(
    path: Path,
    expected_prompt: Optional[PromptID] = None,
) -> List[TRLResult]:
    validate_answer_key()
    results: List[TRLResult] = []
    seen_ids = set()
    if not path.exists():
        return results
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                result = TRLResult(**json.loads(line))
            except Exception as exc:
                raise ValueError(
                    f"Invalid result at {path}:{line_number}: {exc}"
                ) from exc
            if expected_prompt is not None and result.prompt_id != expected_prompt:
                raise ValueError(
                    f"Unexpected template ID at {path}:{line_number}: "
                    f"{result.prompt_id}"
                )
            expected_trl = TARGET_TRL_BY_PROJECT_ID.get(result.project_id)
            if expected_trl is None:
                raise ValueError(
                    f"Unknown record ID at {path}:{line_number}: "
                    f"{result.project_id}"
                )
            if result.ground_truth_trl != expected_trl:
                raise ValueError(
                    f"Reference-value mismatch at {path}:{line_number} for "
                    f"{result.project_id}: expected {expected_trl}, got "
                    f"{result.ground_truth_trl}"
                )
            if result.project_id in seen_ids:
                raise ValueError(
                    f"Duplicate record ID at {path}:{line_number}: "
                    f"{result.project_id}"
                )
            seen_ids.add(result.project_id)
            results.append(result)
    return results


def write_json(path: Path, payload: Any) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)


def append_failure(path: Path, payload: Dict[str, Any]) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False) + "\n")


def write_results_atomically(path: Path, results: Iterable[TRLResult]) -> None:
    temporary_path = path.with_name(path.name + ".tmp")
    try:
        with temporary_path.open("w", encoding="utf-8") as handle:
            for result in results:
                handle.write(result.model_dump_json(by_alias=True) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_path, path)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


def run_answer_prompt(
    *,
    items,
    source_count: int,
    prompt_id: PromptID,
    temperature: float,
    model: str,
    output_dir: Path,
    resume: bool,
    evaluator: CandidateEvaluator,
) -> Dict[str, Any]:
    details_path, answer_failures_path = answer_output_paths(
        output_dir, model, prompt_id, temperature
    )
    existing_results = (
        load_results(details_path, expected_prompt=prompt_id) if resume else []
    )
    finished_ids = {result.project_id for result in existing_results}
    tasks = [item for item in items if item.project_id not in finished_ids]

    print(f"\n=== M2 {prompt_id}, temperature={temperature} ===")
    print(f"Selected: {len(items)}; completed: {len(existing_results)}; pending: {len(tasks)}")

    if tasks:
        with details_path.open("a", encoding="utf-8") as details_handle:
            for index, item in enumerate(tasks, start=1):
                try:
                    result = evaluator.evaluate(item, prompt_id, temperature)
                except Exception as exc:
                    append_failure(
                        answer_failures_path,
                        {
                            "timestamp": datetime.now().isoformat(timespec="seconds"),
                            "prompt_id": prompt_id,
                            "project_id": item.project_id,
                            "error": str(exc),
                        },
                    )
                    print(f"[{index}/{len(tasks)}] Failed {item.project_id}: {exc}")
                    continue

                details_handle.write(result.model_dump_json(by_alias=True) + "\n")
                details_handle.flush()
                existing_results.append(result)
                print(
                    f"[{index}/{len(tasks)}] {item.project_id}: "
                    f"Ref={item.target_trl}, Out={result.metrics}"
                )

    answer_failures = max(0, len(items) - len(existing_results))
    return {
        "prompt_id": prompt_id,
        "details_path": str(details_path),
        "source_question_count": source_count,
        "selected_question_count": len(items),
        "result_count": len(existing_results),
        "answer_failures": answer_failures,
    }


def run_judge_file(
    *,
    details_path: Path,
    rescore_all: bool,
    judge: ReasoningJudge,
) -> Dict[str, Any]:
    results = load_results(details_path)
    if not results:
        raise ValueError(f"Details file contains no valid results: {details_path}")

    target_indices = [
        index
        for index, result in enumerate(results)
        if rescore_all or result.reasoning_score is None
    ]
    judge_failures_path = details_path.with_name(
        f"failed_judgments_{details_path.stem}.jsonl"
    )

    print(f"\n=== Secondary stage {details_path.name} ===")
    print(f"Rows: {len(results)}; pending: {len(target_indices)}")

    if target_indices:
        for completed, row_index in enumerate(target_indices, start=1):
            result = results[row_index]
            try:
                results[row_index] = judge.evaluate(result)
            except Exception as exc:
                failure = {
                    "timestamp": datetime.now().isoformat(timespec="seconds"),
                    "prompt_id": result.prompt_id,
                    "project_id": result.project_id,
                    "error": str(exc),
                }
                raw_judge_response = getattr(exc, "raw_response", None)
                if raw_judge_response is not None:
                    failure["raw_judge_response"] = raw_judge_response
                append_failure(judge_failures_path, failure)
                print(
                    f"[{completed}/{len(target_indices)}] Secondary stage failed "
                    f"{result.project_id}: {exc}"
                )
                continue
            print(
                f"[{completed}/{len(target_indices)}] Secondary stage complete "
                f"{result.project_id}: score={results[row_index].reasoning_score}"
            )
        write_results_atomically(details_path, results)

    missing_scores = sum(result.reasoning_score is None for result in results)
    return {
        "details_path": str(details_path),
        "result_count": len(results),
        "reasoning_scored": len(results) - missing_scores,
        "judge_failures": missing_scores,
    }


def write_run_config(
    output_dir: Path,
    args: argparse.Namespace,
    prompt_ids: List[PromptID],
    data_path: Optional[Path],
    details_files: List[Path],
    input_contract: Dict[str, Any],
) -> None:
    details_inputs = [
        {
            "path": str(path),
            "sha256": sha256_file(path),
        }
        for path in details_files
    ]
    payload = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "stage": args.stage,
        "data_path": str(data_path) if data_path else None,
        "data_sha256": input_contract["dataset_sha256"],
        **input_contract,
        "details_inputs": details_inputs,
        "prompt_ids": prompt_ids,
        "prompt_protocol_sha256": prompt_protocol_hashes(),
        "temperature": args.temperature,
        "model": args.model or None,
        "base_url": args.base_url or None,
        "api_key_env": args.api_key_env or None,
        "judge_model": args.judge_model or None,
        "judge_base_url": args.judge_base_url or None,
        "judge_api_key_env": args.judge_api_key_env or None,
        "judge_protocol": (
            PromptManager.JUDGE_PROTOCOL
            if args.stage in {"judge", "all"}
            else None
        ),
        "judge_temperature": (
            0.0 if args.stage in {"judge", "all"} else None
        ),
        "limit": args.limit,
        "resume": args.resume,
        "rescore_all": args.rescore_all,
        "output_dir": str(output_dir),
    }
    write_json(run_config_path(output_dir, args), payload)


def run_config_path(output_dir: Path, args: argparse.Namespace) -> Path:
    name = "run_config.json"
    if args.stage in {"answer", "all"} and args.temperature is not None:
        name = f"run_config_{safe_model_name(args.model)}_temp{args.temperature}.json"
    return output_dir / name


def validate_resume_input_contract(
    output_dir: Path,
    args: argparse.Namespace,
    input_contract: Dict[str, Any],
) -> None:
    if not args.resume:
        return
    config_path = run_config_path(output_dir, args)
    if not config_path.is_file():
        raise ValueError(
            "Cannot resume without the existing run configuration: "
            f"{config_path}"
        )
    try:
        previous = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(
            f"Cannot read the existing run configuration: {config_path}: {exc}"
        ) from exc
    required = (
        "input_contract_version",
        "dataset_sha256",
        "answer_key_sha256",
        "answer_count",
        "joint_input_sha256",
    )
    missing = [field for field in required if field not in previous]
    if missing:
        raise ValueError(
            "Cannot resume; required input-contract fields are missing: "
            + ", ".join(missing)
        )
    mismatches = [
        field
        for field in required
        if previous.get(field) != input_contract.get(field)
    ]
    if mismatches:
        details = "; ".join(
            f"{field}: previous={previous.get(field)!r}, "
            f"current={input_contract.get(field)!r}"
            for field in mismatches
        )
        raise ValueError(f"Resume input contract mismatch: {details}")


def main(
    argv=None,
    *,
    candidate_client: Optional[Any] = None,
    judge_client: Optional[Any] = None,
) -> int:
    args = parse_args(argv)
    try:
        resolved = validate_runtime_inputs(args)
    except ValueError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2

    answer_summaries = []
    judge_summaries = []
    try:
        data = None
        if args.stage in {"answer", "all"}:
            data = DataManager.load_data(resolved["data_path"])
        input_contract = build_input_contract(resolved["data_path"])
        output_dir: Path = resolved["output_dir"]
        validate_resume_input_contract(output_dir, args, input_contract)
        output_dir.mkdir(parents=True, exist_ok=True)
        write_run_config(
            output_dir,
            args,
            resolved["prompt_ids"],
            resolved["data_path"],
            resolved["details_files"],
            input_contract,
        )

        if args.stage in {"answer", "all"}:
            selected_items = data[: args.limit] if args.limit else data
            if candidate_client is None:
                candidate_client = LLMClient(
                    build_api_settings(
                        args.model,
                        args.base_url,
                        args.api_key_env,
                    )
                )
            candidate_evaluator = CandidateEvaluator(candidate_client)
            for prompt_id in resolved["prompt_ids"]:
                answer_summaries.append(
                    run_answer_prompt(
                        items=selected_items,
                        source_count=len(data),
                        prompt_id=prompt_id,
                        temperature=args.temperature,
                        model=args.model,
                        output_dir=output_dir,
                        resume=args.resume,
                        evaluator=candidate_evaluator,
                    )
                )

        if args.stage in {"judge", "all"}:
            if judge_client is None:
                judge_client = LLMClient(
                    build_api_settings(
                        args.judge_model,
                        args.judge_base_url,
                        args.judge_api_key_env,
                    )
                )
            judge = ReasoningJudge(judge_client)
            if args.stage == "all":
                details_files = [
                    Path(summary["details_path"])
                    for summary in answer_summaries
                ]
            else:
                details_files = resolved["details_files"]
            for details_path in details_files:
                judge_summaries.append(
                    run_judge_file(
                        details_path=details_path,
                        rescore_all=args.rescore_all,
                        judge=judge,
                    )
                )
    except Exception as exc:
        print(f"Run failed: {exc}", file=sys.stderr)
        return 1

    summary = {
        "stage": args.stage,
        "answers": answer_summaries,
        "judgments": judge_summaries,
    }
    write_json(output_dir / "task2_reproduction_summary.json", summary)
    print(f"\nSummary: {output_dir / 'task2_reproduction_summary.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
