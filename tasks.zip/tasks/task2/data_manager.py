import json
from pathlib import Path
from typing import List

from pydantic import ValidationError

from schemas import TRLData, TRLQuestion
from task2_answer_key import TARGET_TRL_BY_PROJECT_ID, validate_answer_key


class DataManager:
    @staticmethod
    def load_data(file_path: str | Path) -> List[TRLData]:
        path = Path(file_path)
        if not path.is_file():
            raise FileNotFoundError(f"Data file not found: {path}")

        questions: List[TRLQuestion] = []
        seen_ids = set()
        with path.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                if not line.strip():
                    continue
                try:
                    raw = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(
                        f"Invalid JSON at {path}:{line_number}: {exc.msg}"
                    ) from exc
                if not isinstance(raw, dict):
                    raise ValueError(
                        f"M2 row must be a JSON object at "
                        f"{path}:{line_number}"
                    )
                try:
                    item = TRLQuestion(**raw)
                except ValidationError as exc:
                    raise ValueError(
                        f"Invalid M2 record at {path}:{line_number}: {exc}"
                    ) from exc

                if item.project_id in seen_ids:
                    raise ValueError(
                        f"Duplicate record ID at {path}:{line_number}: "
                        f"{item.project_id}"
                    )
                seen_ids.add(item.project_id)
                questions.append(item)

        if not questions:
            raise ValueError(f"Data file contains no M2 records: {path}")

        data_ids = set(seen_ids)
        answer_ids = set(TARGET_TRL_BY_PROJECT_ID)
        missing_answers = sorted(data_ids - answer_ids)
        extra_answers = sorted(answer_ids - data_ids)
        if missing_answers or extra_answers:
            details = []
            if missing_answers:
                details.append(
                    "missing answer IDs=" + ", ".join(missing_answers[:10])
                )
            if extra_answers:
                details.append(
                    "answer IDs absent from data=" + ", ".join(extra_answers[:10])
                )
            raise ValueError(
                "M2 data/reference-map ID coverage mismatch: "
                + "; ".join(details)
            )

        validate_answer_key()
        return [
            TRLData(
                **question.model_dump(by_alias=True),
                **{"Target TRL": TARGET_TRL_BY_PROJECT_ID[question.project_id]},
            )
            for question in questions
        ]
