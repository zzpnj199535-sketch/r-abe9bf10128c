import json
import time
from typing import Any, Dict, List, Optional

import requests

from config import APISettings


class LLMClient:
    def __init__(self, settings: APISettings):
        self.settings = settings

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.settings.api_key}",
            "Content-Type": "application/json",
        }

    @staticmethod
    def _content_to_text(content: Any) -> str:
        if isinstance(content, str):
            return content.strip()
        if isinstance(content, list):
            parts = []
            for block in content:
                if isinstance(block, str):
                    parts.append(block)
                elif isinstance(block, dict):
                    text = block.get("text") or block.get("content")
                    if isinstance(text, str):
                        parts.append(text)
            return "\n".join(parts).strip()
        return ""

    @classmethod
    def _extract_response_text(cls, payload: Dict[str, Any]) -> str:
        choices = payload.get("choices")
        if not isinstance(choices, list) or not choices:
            raise ValueError("API response does not contain choices")
        choice = choices[0]
        if not isinstance(choice, dict):
            raise ValueError("API response choice is not an object")

        message = choice.get("message")
        if isinstance(message, dict):
            for key in ("content", "reasoning_content", "reasoning"):
                text = cls._content_to_text(message.get(key))
                if text:
                    return text
        text = cls._content_to_text(choice.get("text"))
        if text:
            return text
        raise ValueError("API response does not contain assistant text")

    def call_model(
        self,
        messages: List[Dict[str, str]],
        *,
        temperature: float,
        max_tokens: Optional[int] = None,
    ) -> str:
        request_payload: Dict[str, Any] = {
            "model": self.settings.model,
            "messages": messages,
            "temperature": temperature,
            "stream": False,
        }
        if max_tokens is not None:
            request_payload["max_tokens"] = max_tokens

        last_error: Optional[Exception] = None
        endpoint = f"{self.settings.base_url.rstrip('/')}/chat/completions"
        for attempt in range(self.settings.retry_attempts):
            try:
                response = requests.post(
                    endpoint,
                    headers=self._headers(),
                    json=request_payload,
                    timeout=self.settings.request_timeout,
                )
                response.raise_for_status()
                return self._extract_response_text(response.json())
            except (
                requests.RequestException,
                json.JSONDecodeError,
                KeyError,
                TypeError,
                ValueError,
            ) as exc:
                last_error = exc
                if attempt < self.settings.retry_attempts - 1:
                    time.sleep(self.settings.retry_delay)

        raise RuntimeError(
            f"LLM call failed after {self.settings.retry_attempts} attempts: "
            f"{last_error}"
        )

    def list_models(self) -> List[str]:
        endpoint = f"{self.settings.base_url.rstrip('/')}/models"
        try:
            response = requests.get(
                endpoint,
                headers=self._headers(),
                timeout=self.settings.request_timeout,
            )
            response.raise_for_status()
            payload = response.json()
        except (
            requests.RequestException,
            json.JSONDecodeError,
            TypeError,
            ValueError,
        ) as exc:
            raise RuntimeError(f"Could not query API model list: {exc}") from exc

        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, list):
            raise RuntimeError("API model-list response does not contain a data array")
        model_ids = [
            item.get("id")
            for item in data
            if isinstance(item, dict) and isinstance(item.get("id"), str)
        ]
        if not model_ids:
            raise RuntimeError("API model-list response contains no model IDs")
        return model_ids
