import os
from dataclasses import dataclass


@dataclass(frozen=True)
class APISettings:


    model: str = ""
    base_url: str = ""
    api_key_env: str = ""
    retry_attempts: int = 3
    retry_delay: float = 2.0
    request_timeout: float = 180.0

    @property
    def api_key(self) -> str:
        if not self.api_key_env:
            raise RuntimeError("API key environment variable name is not configured.")
        value = os.getenv(self.api_key_env)
        if not value:
            raise RuntimeError(
                f"Missing API key environment variable: {self.api_key_env}"
            )
        return value
