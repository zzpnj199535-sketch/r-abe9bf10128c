from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


PromptID = Literal["PA1", "PA2", "PA3"]
JudgeParseFormat = Literal["json", "prometheus_result"]
JudgeProtocolID = Literal["appendix_s2_json"]


def normalize_target_trl(value: Any) -> int:
    if isinstance(value, bool):
        raise ValueError("Target value cannot be a boolean")
    if isinstance(value, list):
        if len(value) != 1:
            raise ValueError(
                f"Target list must contain exactly one value: {value}"
            )
        value = value[0]
    if isinstance(value, float):
        if not value.is_integer():
            raise ValueError(f"Target value must be an integer: {value}")
        value = int(value)
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            raise ValueError("Target value is empty")
        try:
            numeric = float(stripped)
        except ValueError as exc:
            raise ValueError(f"Target value is not numeric: {value}") from exc
        if not numeric.is_integer():
            raise ValueError(f"Target value must be an integer: {value}")
        value = int(numeric)
    if not isinstance(value, int):
        raise ValueError(f"Unsupported target value: {value!r}")
    if value < 1 or value > 9:
        raise ValueError(f"Target value must be between 1 and 9: {value}")
    return value


class TRLQuestion(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="forbid")

    project_id: str = Field(alias="Project ID", min_length=1)
    technology_description: str = Field(
        alias="Technology Description", min_length=1
    )


class TRLData(TRLQuestion):


    target_trl: int = Field(alias="Target TRL", ge=1, le=9)

    @field_validator("target_trl", mode="before")
    @classmethod
    def validate_target_trl(cls, value: Any) -> int:
        return normalize_target_trl(value)


class TRLResult(BaseModel):

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    technology_description: str = Field(
        alias="Technology Description", min_length=1
    )
    reasoning_eval: str = Field(alias="Reasoning Eval", min_length=1)
    metrics: int = Field(alias="Metrics", ge=1, le=9)
    project_id: str = Field(min_length=1)
    ground_truth_trl: int = Field(ge=1, le=9)
    prompt_id: PromptID
    reasoning_score: Optional[int] = Field(default=None, ge=1, le=5)
    reasoning_feedback: Optional[str] = None
    raw_judge_response: Optional[str] = None
    judge_parse_format: Optional[JudgeParseFormat] = None
    judge_protocol: Optional[JudgeProtocolID] = None
